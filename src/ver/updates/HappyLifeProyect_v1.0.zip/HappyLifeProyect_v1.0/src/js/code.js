// Si que eres muy curioso no?

window.onload = inicio();

function inicio() {
  let info = document.querySelector("#info");
  let x = 0;

  info.addEventListener("click", function (e) {
    info.textContent = x + 1 + "...";
    x++;
    if (x == 7) {
      info.href = "https://yyyyyyy.info/";
    }
  });

  console.log(
    "Felicidades por abrir la consola del navegador, que quieres hacer aqui?"
  );
}
