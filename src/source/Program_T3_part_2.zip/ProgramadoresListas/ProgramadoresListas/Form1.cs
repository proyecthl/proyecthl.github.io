﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Usando el espacio de trabajo llamado ProgramadoresListas
namespace ProgramadoresListas
{
    // Clase Form1 que hereda las propiedades de Form
    public partial class Form1 : Form
    {
        // Creando una clase a partir de Datos
        Datos dat = new Datos();
        // Listas de lo numeros
        public List<string> numEx = new List<string>();
        public List<int> listNum = new List<int>();

        // Método del Form1 que iniciará los componenetes
        public Form1()
        {
            InitializeComponent();
        }

        // Método cuando carge el Form
        private void Form1_Load(object sender, EventArgs e)
        {
            // Este método centrara el título del form
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            // Llamando al método
            UpdateTextPosition();
        }

        // Método del evento keypress para el textbox ingresar(presionar tecla)
        private void CajaIngresar_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Le bloqueo las teclas a excepcion de los numeros y la coma
            if ((e.KeyChar >= 32 && e.KeyChar <= 43 || e.KeyChar >= 45 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo debes ingresar numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        // Método del botón insertar
        private void Btn_Insertar_Click(object sender, EventArgs e)
        {
            // Reviso que el textbox no este vacío
            if (String.IsNullOrEmpty(CajaIngresar.Text))
            {
                MessageBox.Show("La caja no pueda estar vacía!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                // Pongo excepciones en caso ponga mal los datos
                try
                {
                    // Limpio la lista
                    listNum.Clear();
                    // Vacío el texbox
                    CajaSalida.Text = "";

                    // Guardo los datos
                    dat.D_Elem = CajaIngresar.Text;
                    // Separo los numeros por coma en una lista
                    numEx = dat.D_Elem.Split(',').ToList();

                    for (int i = 0; i < numEx.Count(); i++)
                    {
                        // Agrego los numeros a la lista
                        listNum.Add(int.Parse(numEx[i]));
                    }

                    // Llamo al metodo mostrar los elementos en el textbox mostrar
                    MostrarElementos();
                } catch
                {
                    MessageBox.Show("Revisa que hayas puesto los datos correctamente!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Método del boton ordenar
        private void Btn_OrdenA_Click(object sender, EventArgs e)
        {
            // Compruebo que la lista no este vacia para ordenar
            if (listNum.Count() == 0)
            {
                MessageBox.Show("Debes insertar numeros para ordenar!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            } else
            {
                // Vacío la caja
                CajaSalida.Text = "";

                // Ordeno la lista
                // Aviso que en el enunciado no dice que utilice metodo burbujar y eso, por eso use sort
                listNum.Sort();

                // Llamo al metodo mostrar los elementos en el textbox mostrar
                MostrarElementos();
            }
        }

        // Método del boton ordenar
        private void Btn_OrdenD_Click(object sender, EventArgs e)
        {
            // Compruebo que la lista no este vacia para ordenar
            if (listNum.Count() == 0)
            {
                MessageBox.Show("Debes insertar numeros para ordenar!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            } else
            {
                // Vacío la caja
                CajaSalida.Text = "";

                // Ordeno la lista
                // Aviso que en el enunciado no dice que utilice metodo burbujar y eso, por eso use sort
                listNum.Sort();
                // Volteo la lista, ya que pide descendente
                listNum.Reverse();

                // Llamo al metodo mostrar los elementos en el textbox mostrar
                MostrarElementos();
            }
        }

        // Método del evento keypress del textbox buscar(presionar tecla)
        private void CajaBuscar_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Bloqueo todo tipo de tecla a excepcion de los numeros
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo debes ingresar numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        // Método del boton buscar
        private void Btn_Buscar_Click(object sender, EventArgs e)
        {
            // Compruebo que el textbox no este vacío
            if (String.IsNullOrEmpty(CajaBuscar.Text))
            {
                MessageBox.Show("Porfavor completa el campo!", "Ayuda", MessageBoxButtons.OK, MessageBoxIcon.Question);
            } else
            {
                // Compruebo que la lista no este vacía antes de hacer la búsqueda
                if (listNum.Count() == 0)
                {
                    MessageBox.Show("Debes insertar numeros para buscar!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                } else
                {
                    // Creo un indice que me servirá en la búsqueda
                    int indice = 0;
                    // Guardo el contenido del textbox
                    dat.D_Search = int.Parse(CajaBuscar.Text);

                    // Llamo al método de buscar pasandole el indice y el número a buscar
                    if (BusquedaRecursiva(dat.D_Search, indice) == 1)
                    {
                        // En caso lo encuentrar avisarle al usuario
                        MessageBox.Show("El número fue encontrado!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        // En caso no se encuentra, avisarle que no se encontró
                        MessageBox.Show("Lamentablemente no se encontro el número", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    // Vacío el textbox
                    CajaBuscar.Text = "";
                }
            }
        }

        // Método que hara una búsqueda usando recursividad
        private int BusquedaRecursiva(int num, int i)
        {
            if (i < listNum.Count())
            {
                if (listNum[i] == num)
                {
                    return 1;
                }
                else
                {
                    return BusquedaRecursiva(num, i + 1);
                }
            }
            return 0;
        }

        // Método del evento keypress del textbox eliminar(presionar tecla)
        private void CajaEliminar_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Bloqueo todo tipo de tecla a excepcion de los numeros
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo debes ingresar numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        // Método del boton eliminar
        private void Btn_Eliminar_Click(object sender, EventArgs e)
        {
            // Comprobamos que la caja no este vacía 
            if (String.IsNullOrEmpty(CajaEliminar.Text))
            {
                MessageBox.Show("Porfavor completa el campo!", "Ayuda", MessageBoxButtons.OK, MessageBoxIcon.Question);
            } else
            {
                // Comprobamos que haya numeros en la lista para eliminar
                if (listNum.Count() == 0)
                {
                    MessageBox.Show("Debes insertar numeros para eliminar!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                } else
                {
                    // Creo un indice que me servira en la busqueda y eliminación del numero
                    int indice2 = 0;
                    // Guardo el contenido del textbox
                    dat.D_Delete = int.Parse(CajaEliminar.Text);

                    // Llamo al método de eliminar pasandole el indice2 y el número a eliminar
                    if (EliminarRecursivo(dat.D_Delete, indice2) == 1)
                    {
                        // En caso lo elimina avisarle al usuario
                        MessageBox.Show("El número fue encontrado y eliminado", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        // En caso no se encuentra, avisarle que no se encontró
                        MessageBox.Show("No se pudo eliminar ya que no fue encontrado el número", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    // Vacío el textbox eliminar
                    CajaEliminar.Text = "";
                    // Vacío el textbox salida
                    CajaSalida.Text = "";
                    // Llamo al método de mostrar, poniendo los datos sin el número eliminado
                    MostrarElementos();
                }
            }
        }

        // Método que elimina un número usando recursividad
        private int EliminarRecursivo(int num2,int j)
        {
            if (j < listNum.Count())
            {
                if (listNum[j] == num2)
                {
                    listNum.Remove(listNum[j]);
                    return 1;
                }
                else
                {
                    return EliminarRecursivo(num2, j + 1);
                }
            }
            return 0;
        }

        // Método que mostrará los elementos de la lista en el textbox salida
        private void MostrarElementos()
        {
            for (int i = 0; i < listNum.Count(); i++)
            {
                CajaSalida.Text += listNum[i] + " ";
            }
        }
            // Code created by Happy Life
            // Discord: https://discord.gg/9fhrdaekpT
            // Sitio Web: https://happylifeproyect.000webhostapp.com/index.html
    }
}
