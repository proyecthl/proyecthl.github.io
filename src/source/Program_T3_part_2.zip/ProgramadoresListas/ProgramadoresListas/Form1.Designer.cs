﻿namespace ProgramadoresListas
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.CajaIngresar = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CajaEliminar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Btn_Eliminar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.CajaBuscar = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Btn_Buscar = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Btn_OrdenD = new System.Windows.Forms.Button();
            this.Btn_OrdenA = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CajaSalida = new System.Windows.Forms.RichTextBox();
            this.Btn_Insertar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CajaIngresar
            // 
            this.CajaIngresar.Location = new System.Drawing.Point(49, 162);
            this.CajaIngresar.Name = "CajaIngresar";
            this.CajaIngresar.Size = new System.Drawing.Size(140, 78);
            this.CajaIngresar.TabIndex = 0;
            this.CajaIngresar.Text = "Ingresa aqui números Ejemplo: 3,2,1";
            this.CajaIngresar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CajaIngresar_KeyPress);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightGray;
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.CajaSalida);
            this.groupBox1.Controls.Add(this.Btn_Insertar);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.CajaIngresar);
            this.groupBox1.Location = new System.Drawing.Point(57, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(685, 401);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Admin:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Goldenrod;
            this.panel3.Controls.Add(this.CajaEliminar);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.Btn_Eliminar);
            this.panel3.Location = new System.Drawing.Point(244, 275);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(181, 120);
            this.panel3.TabIndex = 7;
            // 
            // CajaEliminar
            // 
            this.CajaEliminar.Location = new System.Drawing.Point(29, 44);
            this.CajaEliminar.Name = "CajaEliminar";
            this.CajaEliminar.Size = new System.Drawing.Size(129, 20);
            this.CajaEliminar.TabIndex = 8;
            this.CajaEliminar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CajaEliminar_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(24, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 19);
            this.label5.TabIndex = 5;
            this.label5.Text = "Eliminar número";
            // 
            // Btn_Eliminar
            // 
            this.Btn_Eliminar.Location = new System.Drawing.Point(28, 85);
            this.Btn_Eliminar.Name = "Btn_Eliminar";
            this.Btn_Eliminar.Size = new System.Drawing.Size(130, 23);
            this.Btn_Eliminar.TabIndex = 4;
            this.Btn_Eliminar.Text = "Eliminar";
            this.Btn_Eliminar.UseVisualStyleBackColor = true;
            this.Btn_Eliminar.Click += new System.EventHandler(this.Btn_Eliminar_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightBlue;
            this.panel2.Controls.Add(this.CajaBuscar);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.Btn_Buscar);
            this.panel2.Location = new System.Drawing.Point(244, 147);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(181, 118);
            this.panel2.TabIndex = 6;
            // 
            // CajaBuscar
            // 
            this.CajaBuscar.Location = new System.Drawing.Point(29, 48);
            this.CajaBuscar.Name = "CajaBuscar";
            this.CajaBuscar.Size = new System.Drawing.Size(129, 20);
            this.CajaBuscar.TabIndex = 5;
            this.CajaBuscar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CajaBuscar_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "Buscar número:";
            // 
            // Btn_Buscar
            // 
            this.Btn_Buscar.Location = new System.Drawing.Point(29, 83);
            this.Btn_Buscar.Name = "Btn_Buscar";
            this.Btn_Buscar.Size = new System.Drawing.Size(129, 23);
            this.Btn_Buscar.TabIndex = 3;
            this.Btn_Buscar.Text = "Buscar";
            this.Btn_Buscar.UseVisualStyleBackColor = true;
            this.Btn_Buscar.Click += new System.EventHandler(this.Btn_Buscar_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.Btn_OrdenD);
            this.panel1.Controls.Add(this.Btn_OrdenA);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(245, 18);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(180, 123);
            this.panel1.TabIndex = 5;
            // 
            // Btn_OrdenD
            // 
            this.Btn_OrdenD.Location = new System.Drawing.Point(29, 90);
            this.Btn_OrdenD.Name = "Btn_OrdenD";
            this.Btn_OrdenD.Size = new System.Drawing.Size(129, 23);
            this.Btn_OrdenD.TabIndex = 2;
            this.Btn_OrdenD.Text = "Orden descendente";
            this.Btn_OrdenD.UseVisualStyleBackColor = true;
            this.Btn_OrdenD.Click += new System.EventHandler(this.Btn_OrdenD_Click);
            // 
            // Btn_OrdenA
            // 
            this.Btn_OrdenA.Location = new System.Drawing.Point(29, 51);
            this.Btn_OrdenA.Name = "Btn_OrdenA";
            this.Btn_OrdenA.Size = new System.Drawing.Size(129, 23);
            this.Btn_OrdenA.TabIndex = 1;
            this.Btn_OrdenA.Text = "Orden ascendente";
            this.Btn_OrdenA.UseVisualStyleBackColor = true;
            this.Btn_OrdenA.Click += new System.EventHandler(this.Btn_OrdenA_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(47, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "Ordenar:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(498, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "Salida:";
            // 
            // CajaSalida
            // 
            this.CajaSalida.Enabled = false;
            this.CajaSalida.Location = new System.Drawing.Point(461, 163);
            this.CajaSalida.Name = "CajaSalida";
            this.CajaSalida.Size = new System.Drawing.Size(140, 77);
            this.CajaSalida.TabIndex = 3;
            this.CajaSalida.Text = "";
            // 
            // Btn_Insertar
            // 
            this.Btn_Insertar.Location = new System.Drawing.Point(49, 255);
            this.Btn_Insertar.Name = "Btn_Insertar";
            this.Btn_Insertar.Size = new System.Drawing.Size(140, 23);
            this.Btn_Insertar.TabIndex = 2;
            this.Btn_Insertar.Text = "Insertar";
            this.Btn_Insertar.UseVisualStyleBackColor = true;
            this.Btn_Insertar.Click += new System.EventHandler(this.Btn_Insertar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(45, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingresar numeros:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Listas";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox CajaIngresar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox CajaEliminar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Btn_Eliminar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox CajaBuscar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Btn_Buscar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Btn_OrdenD;
        private System.Windows.Forms.Button Btn_OrdenA;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox CajaSalida;
        private System.Windows.Forms.Button Btn_Insertar;
        private System.Windows.Forms.Label label1;
    }
}

