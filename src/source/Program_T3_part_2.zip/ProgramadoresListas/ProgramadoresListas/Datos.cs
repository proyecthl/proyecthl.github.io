﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Usando el espacio de trabajo llamado ProgramadoresListas
namespace ProgramadoresListas
{
    // Clase Datos, donde estaran variables que guardaran sus respectivos contenidos de textbox
    public class Datos
    {
        public int D_Search { get; set; }
        public int D_Delete { get; set; }
        public string D_Elem { get; set; }
    }
}
