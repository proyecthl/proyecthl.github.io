﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Usando un nombre de espacios llamado Programadores
namespace Programadores
{
    // Se crea la clase Form1 heredando las propiedades de Form
    public partial class Form1 : Form
    {
        // Creo listas de los datos de los Dueños
        public List<string> listPerName = new List<string>();
        public List<string> listPerDirec = new List<string>();
        public List<int> listPerTel = new List<int>();

        Dueños per = new Dueños();

        // Creo listas de los datos de las Mascotas
        public List<string> listAniDueño = new List<string>();
        public List<string> listAniName = new List<string>();
        public List<int> listAniAge = new List<int>();
        public List<string> listAniRaza = new List<string>();
        
        Mascotas ani = new Mascotas();

        // Iniciando Form
        public Form1()
        {
            InitializeComponent();
        }

        // Método cuando carge el formulario
        private void Form1_Load(object sender, EventArgs e)
        {
            // Lo que hará es centrar el título del form
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            // Llamando al método de centrar
            UpdateTextPosition();
        }

        // Método del boton registrar Dueños
        private void Btn_Registrar_Click(object sender, EventArgs e)
        {
            // Ponemos excepeción try y catch en caso no ponga numeros donde debería ser el teléfono
            try
            {
                // Comprobamos si los textbox estan vacios para avisarle al usuario
                if (String.IsNullOrEmpty(CajaNombreD.Text) | String.IsNullOrEmpty(CajaDireccion.Text) | String.IsNullOrEmpty(CajaTelefono.Text))
                {
                    MessageBox.Show("Los campos no pueden estar vacios!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                } else
                {
                    // Guardamos los datos en sus respectivas variables
                    per.D_NameD = CajaNombreD.Text;
                    per.D_Home = CajaDireccion.Text;
                    per.D_Tel = int.Parse(CajaTelefono.Text);

                    // Comprobamos que el teléfono tenga 9 numeros, en caso contrario avisarle que deben ser 9
                    if (CajaTelefono.Text.Length == 9)
                    {
                        // Agregando a las lista de Dueños
                        listPerName.Add(per.D_NameD);
                        listPerDirec.Add(per.D_Home);
                        listPerTel.Add(per.D_Tel);

                        // Agregando a la "listview" del form
                        ListViewItem fila = new ListViewItem(per.D_NameD);
                        fila.SubItems.Add(per.D_Home);
                        fila.SubItems.Add((per.D_Tel).ToString());
                        listView1.Items.Add(fila);

                        // Agregando el dueño al combobox de Mascotas
                        ComboBoxMas.Items.Add(per.D_NameD);

                        // Vaciando los textbox para que ponga otros datos
                        CajaNombreD.Text = "";
                        CajaDireccion.Text = "";
                        CajaTelefono.Text = "";
                    } else
                    {
                        MessageBox.Show("El número de teléfono debe llevar 9 dígitos", "Ayuda", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch
            {
                MessageBox.Show("El telefono solo puede llevar numeros, tambíen no te olvides escribir todo junto!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método del evento keypress del combobox(presionar tecla)
        private void ComboBoxMas_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Si el intenta escribir en el combobox, le aviso que no debe hacerlo y si no hay datos debe registrar en Dueños
            if ((e.KeyChar >= 32 && e.KeyChar <= 255))
            {
                MessageBox.Show("No escribas, selecciona una de las opciones! \n\nEn caso esten vacias, debes registrar dueños", "Ayuda", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Handled = true;
                return;
            }
        }

        // Método de registrar Mascotas
        private void Btn_RegistrarMas_Click(object sender, EventArgs e)
        {
            // Ponemos excepeción try y catch en caso no ponga numeros donde deberia ser la edad de la mascota
            try
            {
                // Comprobamos si los textbox estan vacios para avisarle al usuario
                if (String.IsNullOrEmpty(CajaNombreM.Text) | String.IsNullOrEmpty(CajaEdad.Text) | String.IsNullOrEmpty(CajaRaza.Text) | String.IsNullOrEmpty(ComboBoxMas.Text))
                {
                    MessageBox.Show("Los campos no pueden estar vacios!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                } else
                {
                    // Guardamos los datos en sus respectivas variables
                    ani.M_Dueño = ComboBoxMas.Text;
                    ani.M_NameM = CajaNombreM.Text;
                    ani.M_Age = int.Parse(CajaEdad.Text);
                    ani.M_Raza = CajaRaza.Text;

                    // Comprobamos que la edad este entre 1 y 20(promedio de vida de una mascota)
                    if (ani.M_Age < 1 | ani.M_Age > 20)
                    {
                        MessageBox.Show("Debes escribir una edad entre 1 y 20(promedio de vida de un animal)","Ayuda",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    } else
                    {
                        // Agregando a las lista de Mascotas
                        listAniDueño.Add(ani.M_Dueño);
                        listAniName.Add(ani.M_NameM);
                        listAniAge.Add(ani.M_Age);
                        listAniRaza.Add(ani.M_Raza);

                        // Agregando a la "listview2" del form
                        ListViewItem fila2 = new ListViewItem(ani.M_Dueño);
                        fila2.SubItems.Add(ani.M_NameM);
                        fila2.SubItems.Add((ani.M_Age).ToString());
                        fila2.SubItems.Add(ani.M_Raza);
                        listView2.Items.Add(fila2);

                        // Vaciando los textbox para que ponga otros datos
                        ComboBoxMas.Text = "";
                        CajaNombreM.Text = "";
                        CajaEdad.Text = "";
                        CajaRaza.Text = "";
                    }
                }
            } catch
            {
                MessageBox.Show("La edad solo deben ser numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método del boton buscar
        private void Btn_Buscar_Click(object sender, EventArgs e)
        {
            // Compprobamos que el textbox no este vacío
            if (String.IsNullOrEmpty(CajaBuscar.Text))
            {
                MessageBox.Show("Porfavor completa el campo!", "Ayuda", MessageBoxButtons.OK, MessageBoxIcon.Question);
            } else
            {
                // Comprobamos que haya registrado al menos 1 animal para hacer la búsqueda
                if (listAniName.Count() == 0)
                {
                    MessageBox.Show("Debes registrar mascotas para buscar!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                } else
                {
                    // En caso si haya registrado hacemos una busqueda llamando a un método
                    int indice = 0;
                    ani.M_Content = CajaBuscar.Text;

                    string res = BusquedaRecursiva(ani.M_Content, indice);
                    MessageBox.Show(res, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        // Creo un método que hara una búsqueda usando recursividad
        private string BusquedaRecursiva(string elem, int i)
        {
            if (i < listAniName.Count())
            {
                if (listAniName[i] == elem)
                {
                    return "Se encontro la mascota!";
                } else
                {
                    return BusquedaRecursiva(elem, i + 1);
                }
            }
            return "La mascota no esta registrada!";
        }
            // Code created by Happy Life
            // Discord: https://discord.gg/9fhrdaekpT
            // Sitio Web: https://happylifeproyect.000webhostapp.com/index.html
    }
}
