﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Usando un nombre de espacios llamado Programadores
namespace Programadores
{
    // Creo dos clases publicas Dueños y Mascotas que tendrán sus respectivos datos
    public class Dueños
    {
        public string D_NameD { get; set; }
        public string D_Home { get; set; }
        public int D_Tel { get; set; }
    }

    public class Mascotas
    {
        public string M_Dueño { get; set; }
        public string M_NameM { get; set; }
        public int M_Age { get; set; }
        public string M_Raza { get; set; }

        public string M_Content { get; set; }
    }
}
