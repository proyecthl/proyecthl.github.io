﻿namespace FormProyectSemana14
{
    partial class Semana11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Semana11));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LblSalida = new System.Windows.Forms.Label();
            this.Caja_Contenido = new System.Windows.Forms.RichTextBox();
            this.Caja_Salida = new System.Windows.Forms.RichTextBox();
            this.Btn_Leer = new System.Windows.Forms.Button();
            this.Btn_Escribir = new System.Windows.Forms.Button();
            this.Btn_Seleccionar = new System.Windows.Forms.Button();
            this.Caja_Nombre = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(279, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(264, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Archivos de Texto";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.LblSalida);
            this.groupBox1.Controls.Add(this.Caja_Contenido);
            this.groupBox1.Controls.Add(this.Caja_Salida);
            this.groupBox1.Controls.Add(this.Btn_Leer);
            this.groupBox1.Controls.Add(this.Btn_Escribir);
            this.groupBox1.Controls.Add(this.Btn_Seleccionar);
            this.groupBox1.Controls.Add(this.Caja_Nombre);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(144, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(532, 325);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Archivos:";
            // 
            // LblSalida
            // 
            this.LblSalida.AutoSize = true;
            this.LblSalida.Location = new System.Drawing.Point(19, 242);
            this.LblSalida.Name = "LblSalida";
            this.LblSalida.Size = new System.Drawing.Size(10, 13);
            this.LblSalida.TabIndex = 10;
            this.LblSalida.Text = ".";
            // 
            // Caja_Contenido
            // 
            this.Caja_Contenido.Location = new System.Drawing.Point(110, 90);
            this.Caja_Contenido.Name = "Caja_Contenido";
            this.Caja_Contenido.Size = new System.Drawing.Size(100, 96);
            this.Caja_Contenido.TabIndex = 9;
            this.Caja_Contenido.Text = "";
            // 
            // Caja_Salida
            // 
            this.Caja_Salida.Location = new System.Drawing.Point(273, 37);
            this.Caja_Salida.Name = "Caja_Salida";
            this.Caja_Salida.Size = new System.Drawing.Size(187, 200);
            this.Caja_Salida.TabIndex = 8;
            this.Caja_Salida.Text = "";
            // 
            // Btn_Leer
            // 
            this.Btn_Leer.Location = new System.Drawing.Point(273, 267);
            this.Btn_Leer.Name = "Btn_Leer";
            this.Btn_Leer.Size = new System.Drawing.Size(187, 34);
            this.Btn_Leer.TabIndex = 7;
            this.Btn_Leer.Text = "Leer";
            this.Btn_Leer.UseVisualStyleBackColor = true;
            this.Btn_Leer.Click += new System.EventHandler(this.Btn_Leer_Click);
            // 
            // Btn_Escribir
            // 
            this.Btn_Escribir.Location = new System.Drawing.Point(22, 267);
            this.Btn_Escribir.Name = "Btn_Escribir";
            this.Btn_Escribir.Size = new System.Drawing.Size(188, 34);
            this.Btn_Escribir.TabIndex = 6;
            this.Btn_Escribir.Text = "Escribir";
            this.Btn_Escribir.UseVisualStyleBackColor = true;
            this.Btn_Escribir.Click += new System.EventHandler(this.Btn_Escribir_Click);
            // 
            // Btn_Seleccionar
            // 
            this.Btn_Seleccionar.Location = new System.Drawing.Point(110, 206);
            this.Btn_Seleccionar.Name = "Btn_Seleccionar";
            this.Btn_Seleccionar.Size = new System.Drawing.Size(100, 32);
            this.Btn_Seleccionar.TabIndex = 5;
            this.Btn_Seleccionar.Text = "Seleccionar";
            this.Btn_Seleccionar.UseVisualStyleBackColor = true;
            this.Btn_Seleccionar.Click += new System.EventHandler(this.Btn_Seleccionar_Click);
            // 
            // Caja_Nombre
            // 
            this.Caja_Nombre.Location = new System.Drawing.Point(110, 37);
            this.Caja_Nombre.Name = "Caja_Nombre";
            this.Caja_Nombre.Size = new System.Drawing.Size(100, 20);
            this.Caja_Nombre.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(19, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Ubicación:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Contenido:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nombre:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(620, 422);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 19);
            this.label5.TabIndex = 2;
            this.label5.Text = "Created by Happy Life";
            // 
            // Semana11
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Semana11";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Semana 11";
            this.Load += new System.EventHandler(this.Semana11_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox Caja_Contenido;
        private System.Windows.Forms.RichTextBox Caja_Salida;
        private System.Windows.Forms.Button Btn_Leer;
        private System.Windows.Forms.Button Btn_Escribir;
        private System.Windows.Forms.Button Btn_Seleccionar;
        private System.Windows.Forms.TextBox Caja_Nombre;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LblSalida;
        private System.Windows.Forms.Label label5;
    }
}