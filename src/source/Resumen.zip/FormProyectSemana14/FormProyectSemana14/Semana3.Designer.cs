﻿namespace FormProyectSemana14
{
    partial class Semana3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Semana3));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.ref1 = new System.Windows.Forms.LinkLabel();
            this.ref2 = new System.Windows.Forms.LinkLabel();
            this.ref3 = new System.Windows.Forms.LinkLabel();
            this.ref4 = new System.Windows.Forms.LinkLabel();
            this.ref5 = new System.Windows.Forms.LinkLabel();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(275, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(311, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Creado por Happy Life";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(210, 81);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(210, 149);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(210, 214);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(207, 281);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Referencias:";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(210, 300);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(434, 130);
            this.richTextBox1.TabIndex = 5;
            this.richTextBox1.Text = "";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(355, 96);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(164, 19);
            this.linkLabel1.TabIndex = 6;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "github.com/hluciana";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.Location = new System.Drawing.Point(355, 163);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(136, 19);
            this.linkLabel2.TabIndex = 7;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Happy Life#0626";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // ref1
            // 
            this.ref1.AutoSize = true;
            this.ref1.Location = new System.Drawing.Point(224, 313);
            this.ref1.Name = "ref1";
            this.ref1.Size = new System.Drawing.Size(356, 13);
            this.ref1.TabIndex = 9;
            this.ref1.TabStop = true;
            this.ref1.Text = "https://www.discoduroderoer.es/generar-numeros-aleatorios-con-c-sharp/";
            this.ref1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ref1_LinkClicked);
            // 
            // ref2
            // 
            this.ref2.AutoSize = true;
            this.ref2.Location = new System.Drawing.Point(224, 338);
            this.ref2.Name = "ref2";
            this.ref2.Size = new System.Drawing.Size(352, 13);
            this.ref2.TabIndex = 10;
            this.ref2.TabStop = true;
            this.ref2.Text = "https://es.stackoverflow.com/questions/517091/control-de-excepciones";
            this.ref2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ref2_LinkClicked);
            // 
            // ref3
            // 
            this.ref3.AutoSize = true;
            this.ref3.Location = new System.Drawing.Point(224, 362);
            this.ref3.Name = "ref3";
            this.ref3.Size = new System.Drawing.Size(405, 13);
            this.ref3.TabIndex = 11;
            this.ref3.TabStop = true;
            this.ref3.Text = "https://stackoverflow.com/questions/11947314/how-to-center-align-the-title-bar-te" +
    "xt";
            this.ref3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ref3_LinkClicked);
            // 
            // ref4
            // 
            this.ref4.AutoSize = true;
            this.ref4.Location = new System.Drawing.Point(224, 384);
            this.ref4.Name = "ref4";
            this.ref4.Size = new System.Drawing.Size(247, 13);
            this.ref4.TabIndex = 12;
            this.ref4.TabStop = true;
            this.ref4.Text = "https://www.youtube.com/watch?v=xoYiBLggBq8";
            this.ref4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ref4_LinkClicked);
            // 
            // ref5
            // 
            this.ref5.AutoSize = true;
            this.ref5.Location = new System.Drawing.Point(224, 408);
            this.ref5.Name = "ref5";
            this.ref5.Size = new System.Drawing.Size(258, 13);
            this.ref5.TabIndex = 13;
            this.ref5.TabStop = true;
            this.ref5.Text = "https://www.youtube.com/watch?v=vq9RKOXMsnE";
            this.ref5.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ref5_LinkClicked);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(356, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 19);
            this.label3.TabIndex = 14;
            this.label3.Text = "Coming Soon...";
            // 
            // Semana3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ref5);
            this.Controls.Add(this.ref4);
            this.Controls.Add(this.ref3);
            this.Controls.Add(this.ref2);
            this.Controls.Add(this.ref1);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Semana3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Info";
            this.Load += new System.EventHandler(this.Semana3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel ref1;
        private System.Windows.Forms.LinkLabel ref2;
        private System.Windows.Forms.LinkLabel ref3;
        private System.Windows.Forms.LinkLabel ref4;
        private System.Windows.Forms.LinkLabel ref5;
        private System.Windows.Forms.Label label3;
    }
}