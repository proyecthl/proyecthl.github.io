﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormProyectSemana14
{
    public partial class Semana6 : Form
    {
        public Semana6()
        {
            InitializeComponent();
        }

        private void Semana6_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
        }

        public string burbuja;
        public string[] burbujaEx;
        public int[] burbujaInt;
        public int aux;

        private void Caja_Burbuja_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 43 || e.KeyChar >= 45 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Btn_Burbuja_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_Burbuja.Text))
            {
                MessageBox.Show("No puedes ordenar elementos vacios!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                burbuja = Caja_Burbuja.Text;
                Caja_MostrarBur.Text = "";
                burbujaEx = burbuja.Split(',');
                OrdenarBurbuja();
                for (int i = 0; i < burbujaInt.Length; i++)
                {
                    Caja_MostrarBur.Text += burbujaInt[i] + " ";
                }
            }
        }

        private void OrdenarBurbuja()
        {
            burbujaInt = new int[burbujaEx.Length];
            for (int i = 0; i < burbujaInt.Length; i++)
            {
                burbujaInt[i] = int.Parse(burbujaEx[i]);
            }

            for (int i = 0; i < burbujaInt.Length; i++)
            {
                for (int j = 0; j < burbujaInt.Length - i - 1; j++)
                {
                    if (burbujaInt[j] > burbujaInt[j + 1])
                    {
                        aux = burbujaInt[j];
                        burbujaInt[j] = burbujaInt[j + 1];
                        burbujaInt[j + 1] = aux;
                    }
                }
            }
        }

        public string inserccion;
        public string[] inserccionEx;
        public int[] inserccionInt;
        public int aux2;
        public int j;

        private void Caja_Inserccion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 43 || e.KeyChar >= 45 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Btn_Inserccion_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_Inserccion.Text))
            {
                MessageBox.Show("No puedes ordenar elementos vacios!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                inserccion = Caja_Inserccion.Text;
                Caja_MostrarIns.Text = "";
                inserccionEx = inserccion.Split(',');
                OrdenarInserccion();
                for (int i = 0; i < inserccionInt.Length; i++)
                {
                    Caja_MostrarIns.Text += inserccionInt[i] + " ";
                }
            }
        }

        private void OrdenarInserccion()
        {
            inserccionInt = new int[inserccionEx.Length];
            for (int i = 0; i < inserccionInt.Length; i++)
            {
                inserccionInt[i] = int.Parse(inserccionEx[i]);
            }

            for (int i = 0; i < inserccionInt.Length; i++)
            {
                aux2 = inserccionInt[i];
                j = i - 1;
                while (j >= 0 && inserccionInt[j] > aux2)
                {
                    inserccionInt[j + 1] = inserccionInt[j];
                    j--;
                }
                inserccionInt[j + 1] = aux2;
            }
        }

        public string seleccion;
        public string[] seleccionEx;
        public int[] seleccionInt;
        public int menor;
        public int posicion;
        public int aux3;

        private void Caja_Seleccion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 43 || e.KeyChar >= 45 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Btn_Seleccion_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_Seleccion.Text))
            {
                MessageBox.Show("No puedes ordenar elementos vacios!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                seleccion = Caja_Seleccion.Text;
                Caja_MostrarSel.Text = "";
                seleccionEx = seleccion.Split(',');
                OrdenarSeleccion();
                for (int i = 0; i < seleccionInt.Length; i++)
                {
                    Caja_MostrarSel.Text += seleccionInt[i] + " ";
                }
            }
        }

        public void OrdenarSeleccion()
        {
            seleccionInt = new int[seleccionEx.Length];
            for (int i = 0; i < seleccionInt.Length; i++)
            {
                seleccionInt[i] = int.Parse(seleccionEx[i]);
            }

            for (int i = 0; i < seleccionInt.Length - 1; i++)
            {
                menor = seleccionInt[i];
                posicion = i;

                for (int j = i + 1; j < seleccionInt.Length; j++)
                {
                    if (seleccionInt[j] < menor)
                    {
                        menor = seleccionInt[j];
                        posicion = j;
                    }
                }

                if (posicion != i)
                {
                    aux3 = seleccionInt[i];
                    seleccionInt[i] = seleccionInt[posicion];
                    seleccionInt[posicion] = aux3;
                }
            }
        }
    }
}
