﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FormProyectSemana14
{
    public partial class Semana13 : Form
    {
        public Semana13()
        {
            InitializeComponent();
        }

        private void Semana13_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
            LblOrigen.Text = "";
            LblDestino.Text = "";
            LblUbicacion.Text = "";
        }

        public string pathOrigen = String.Empty;
        public string pathDestino = String.Empty;

        private void Btn_Origen_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog ruta = new FolderBrowserDialog();

            if (ruta.ShowDialog() == DialogResult.OK)
            {
                pathOrigen = ruta.SelectedPath;
            }
            LblOrigen.Text = pathOrigen;
        }

        private void Btn_Destino_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog ruta2 = new FolderBrowserDialog();

            if (ruta2.ShowDialog() == DialogResult.OK)
            {
                pathDestino = ruta2.SelectedPath;
            }
            LblDestino.Text = pathDestino;
        }

        private void Btn_Mover_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_NombreMov.Text))
            {
                MessageBox.Show("No puede estar vacío el textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                try
                {
                    if (pathOrigen == String.Empty | pathDestino == String.Empty)
                    {
                        MessageBox.Show("Revisa que hayas seleccionado el origen y destino!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    } else
                    {
                        if (File.Exists(pathOrigen + "\\" + Caja_NombreMov.Text + ".txt"))
                        {
                            File.Move(pathOrigen + "\\" + Caja_NombreMov.Text + ".txt", pathDestino + "\\" + Caja_NombreMov.Text + ".txt");
                        } else
                        {
                            MessageBox.Show("Parece que el archivo a mover no existe...!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                } catch
                {
                    MessageBox.Show("Parece que hubo un error...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public string pathUbicacion = String.Empty;

        private void Btn_Ubicacion_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog ruta3 = new FolderBrowserDialog();

            if (ruta3.ShowDialog() == DialogResult.OK)
            {
                pathUbicacion = ruta3.SelectedPath;
            }
            LblUbicacion.Text = pathUbicacion;
        }

        private void Btn_Eliminar_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_NombreDel.Text))
            {
                MessageBox.Show("No puede estar vacío el textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                try
                {
                    if (pathUbicacion == String.Empty)
                    {
                        MessageBox.Show("Porfavor selecciona una ubicación!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    } else
                    {
                        if (File.Exists(pathUbicacion + "\\" + Caja_NombreDel.Text + ".txt"))
                        {
                            File.Delete(pathUbicacion + "\\" + Caja_NombreDel.Text + ".txt");
                        } else
                        {
                            MessageBox.Show("Parece que el archivo no existe...!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                } catch
                {
                    MessageBox.Show("Parece que hubo un error...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
