﻿namespace FormProyectSemana14
{
    partial class Semana7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Semana7));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Btn_BuscarSec = new System.Windows.Forms.Button();
            this.Btn_RegistrarSec = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.Caja_BuscarSec = new System.Windows.Forms.TextBox();
            this.Caja_RegistrarSec = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Btn_BuscarBin = new System.Windows.Forms.Button();
            this.Btn_RegistrarBin = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Caja_BuscarBin = new System.Windows.Forms.TextBox();
            this.Caja_RegistrarBin = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(244, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(326, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Métodos de Búsqueda";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.Btn_BuscarSec);
            this.groupBox1.Controls.Add(this.Btn_RegistrarSec);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Caja_BuscarSec);
            this.groupBox1.Controls.Add(this.Caja_RegistrarSec);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(182, 80);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(492, 158);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Búsqueda Secuencial";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Ejemplo: 4,3,2,1";
            // 
            // Btn_BuscarSec
            // 
            this.Btn_BuscarSec.Location = new System.Drawing.Point(275, 116);
            this.Btn_BuscarSec.Name = "Btn_BuscarSec";
            this.Btn_BuscarSec.Size = new System.Drawing.Size(145, 23);
            this.Btn_BuscarSec.TabIndex = 5;
            this.Btn_BuscarSec.Text = "Buscar";
            this.Btn_BuscarSec.UseVisualStyleBackColor = true;
            this.Btn_BuscarSec.Click += new System.EventHandler(this.Btn_BuscarSec_Click);
            // 
            // Btn_RegistrarSec
            // 
            this.Btn_RegistrarSec.Location = new System.Drawing.Point(25, 116);
            this.Btn_RegistrarSec.Name = "Btn_RegistrarSec";
            this.Btn_RegistrarSec.Size = new System.Drawing.Size(145, 23);
            this.Btn_RegistrarSec.TabIndex = 4;
            this.Btn_RegistrarSec.Text = "Grabar";
            this.Btn_RegistrarSec.UseVisualStyleBackColor = true;
            this.Btn_RegistrarSec.Click += new System.EventHandler(this.Btn_RegistrarSec_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(290, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Número a buscar:";
            // 
            // Caja_BuscarSec
            // 
            this.Caja_BuscarSec.Location = new System.Drawing.Point(275, 79);
            this.Caja_BuscarSec.Name = "Caja_BuscarSec";
            this.Caja_BuscarSec.Size = new System.Drawing.Size(145, 20);
            this.Caja_BuscarSec.TabIndex = 2;
            this.Caja_BuscarSec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_BuscarSec_KeyPress);
            // 
            // Caja_RegistrarSec
            // 
            this.Caja_RegistrarSec.Location = new System.Drawing.Point(25, 79);
            this.Caja_RegistrarSec.Name = "Caja_RegistrarSec";
            this.Caja_RegistrarSec.Size = new System.Drawing.Size(145, 20);
            this.Caja_RegistrarSec.TabIndex = 1;
            this.Caja_RegistrarSec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_RegistrarSec_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Ingresar Números:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Btn_BuscarBin);
            this.groupBox2.Controls.Add(this.Btn_RegistrarBin);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.Caja_BuscarBin);
            this.groupBox2.Controls.Add(this.Caja_RegistrarBin);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(182, 255);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(492, 152);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Búsqueda Binaria";
            // 
            // Btn_BuscarBin
            // 
            this.Btn_BuscarBin.Location = new System.Drawing.Point(275, 102);
            this.Btn_BuscarBin.Name = "Btn_BuscarBin";
            this.Btn_BuscarBin.Size = new System.Drawing.Size(145, 23);
            this.Btn_BuscarBin.TabIndex = 5;
            this.Btn_BuscarBin.Text = "Buscar";
            this.Btn_BuscarBin.UseVisualStyleBackColor = true;
            this.Btn_BuscarBin.Click += new System.EventHandler(this.Btn_BuscarBin_Click);
            // 
            // Btn_RegistrarBin
            // 
            this.Btn_RegistrarBin.Location = new System.Drawing.Point(25, 102);
            this.Btn_RegistrarBin.Name = "Btn_RegistrarBin";
            this.Btn_RegistrarBin.Size = new System.Drawing.Size(145, 23);
            this.Btn_RegistrarBin.TabIndex = 4;
            this.Btn_RegistrarBin.Text = "Grabar";
            this.Btn_RegistrarBin.UseVisualStyleBackColor = true;
            this.Btn_RegistrarBin.Click += new System.EventHandler(this.Btn_RegistrarBin_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(290, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 16);
            this.label5.TabIndex = 3;
            this.label5.Text = "Número a buscar:";
            // 
            // Caja_BuscarBin
            // 
            this.Caja_BuscarBin.Location = new System.Drawing.Point(275, 67);
            this.Caja_BuscarBin.Name = "Caja_BuscarBin";
            this.Caja_BuscarBin.Size = new System.Drawing.Size(145, 20);
            this.Caja_BuscarBin.TabIndex = 2;
            this.Caja_BuscarBin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_BuscarBin_KeyPress);
            // 
            // Caja_RegistrarBin
            // 
            this.Caja_RegistrarBin.Location = new System.Drawing.Point(25, 67);
            this.Caja_RegistrarBin.Name = "Caja_RegistrarBin";
            this.Caja_RegistrarBin.Size = new System.Drawing.Size(145, 20);
            this.Caja_RegistrarBin.TabIndex = 1;
            this.Caja_RegistrarBin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_RegistrarBin_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Ingresar Números:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(620, 422);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 19);
            this.label7.TabIndex = 3;
            this.label7.Text = "Created by Happy Life";
            // 
            // Semana7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Semana7";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Semana 7";
            this.Load += new System.EventHandler(this.Semana7_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Btn_BuscarSec;
        private System.Windows.Forms.Button Btn_RegistrarSec;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Caja_BuscarSec;
        private System.Windows.Forms.TextBox Caja_RegistrarSec;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Btn_BuscarBin;
        private System.Windows.Forms.Button Btn_RegistrarBin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Caja_BuscarBin;
        private System.Windows.Forms.TextBox Caja_RegistrarBin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}