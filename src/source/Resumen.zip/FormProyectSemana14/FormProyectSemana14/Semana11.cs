﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FormProyectSemana14
{
    public partial class Semana11 : Form
    {
        public Semana11()
        {
            InitializeComponent();
        }

        private void Semana11_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
        }

        public string path = String.Empty;

        private void Btn_Seleccionar_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog ruta = new FolderBrowserDialog();

            if (ruta.ShowDialog() == DialogResult.OK)
            {
                path = ruta.SelectedPath;
            }
            LblSalida.Text = path;
        }

        private void Btn_Escribir_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_Nombre.Text) | String.IsNullOrEmpty(Caja_Contenido.Text))
            {
                MessageBox.Show("Porfavor completa todos los campos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            } else
            {
                try
                {
                    if (path == string.Empty)
                    {
                        MessageBox.Show("Porfavor selecciona una ubicación!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    } else
                    {
                        TextWriter escribir = new StreamWriter(path + "\\" + Caja_Nombre.Text + ".txt", true);
                        escribir.WriteLine(Caja_Contenido.Text);
                        escribir.Close();
                        MessageBox.Show("Guardado con exito!", "Info", MessageBoxButtons.OK);
                    }
                } catch
                {
                    MessageBox.Show("Parece que hubo un error...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Btn_Leer_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(path + "\\" + Caja_Nombre.Text + ".txt"))
                {
                    Caja_Salida.Text = "";
                    TextReader leer = new StreamReader(path + "\\" + Caja_Nombre.Text + ".txt");
                    Caja_Salida.Text += leer.ReadToEnd();
                    leer.Close();
                }
                else
                {
                    MessageBox.Show("Verifica que hayas creado o seleccionado el archivo correcto!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            } catch
            {
                MessageBox.Show("Parece que hubo un error...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
