﻿namespace FormProyectSemana14
{
    partial class Semana6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Semana6));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Btn_Burbuja = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Caja_MostrarBur = new System.Windows.Forms.TextBox();
            this.Caja_Burbuja = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Btn_Inserccion = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Caja_MostrarIns = new System.Windows.Forms.TextBox();
            this.Caja_Inserccion = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Btn_Seleccion = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Caja_MostrarSel = new System.Windows.Forms.TextBox();
            this.Caja_Seleccion = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(225, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(383, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Métodos de Ordenamiento";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.Btn_Burbuja);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Caja_MostrarBur);
            this.groupBox1.Controls.Add(this.Caja_Burbuja);
            this.groupBox1.Location = new System.Drawing.Point(127, 68);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(569, 118);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Método Burbuja";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(37, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Ejemplo: 4,3,2,1";
            // 
            // Btn_Burbuja
            // 
            this.Btn_Burbuja.Location = new System.Drawing.Point(199, 80);
            this.Btn_Burbuja.Name = "Btn_Burbuja";
            this.Btn_Burbuja.Size = new System.Drawing.Size(147, 23);
            this.Btn_Burbuja.TabIndex = 4;
            this.Btn_Burbuja.Text = "Orden Burbuja";
            this.Btn_Burbuja.UseVisualStyleBackColor = true;
            this.Btn_Burbuja.Click += new System.EventHandler(this.Btn_Burbuja_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(419, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Salida:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ingresar números:";
            // 
            // Caja_MostrarBur
            // 
            this.Caja_MostrarBur.Enabled = false;
            this.Caja_MostrarBur.Location = new System.Drawing.Point(376, 59);
            this.Caja_MostrarBur.Name = "Caja_MostrarBur";
            this.Caja_MostrarBur.Size = new System.Drawing.Size(135, 20);
            this.Caja_MostrarBur.TabIndex = 1;
            // 
            // Caja_Burbuja
            // 
            this.Caja_Burbuja.Location = new System.Drawing.Point(40, 59);
            this.Caja_Burbuja.Name = "Caja_Burbuja";
            this.Caja_Burbuja.Size = new System.Drawing.Size(135, 20);
            this.Caja_Burbuja.TabIndex = 0;
            this.Caja_Burbuja.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_Burbuja_KeyPress);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Btn_Inserccion);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.Caja_MostrarIns);
            this.groupBox2.Controls.Add(this.Caja_Inserccion);
            this.groupBox2.Location = new System.Drawing.Point(127, 192);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(569, 118);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Método Insercción";
            // 
            // Btn_Inserccion
            // 
            this.Btn_Inserccion.Location = new System.Drawing.Point(199, 89);
            this.Btn_Inserccion.Name = "Btn_Inserccion";
            this.Btn_Inserccion.Size = new System.Drawing.Size(147, 23);
            this.Btn_Inserccion.TabIndex = 5;
            this.Btn_Inserccion.Text = "Orden Insercción";
            this.Btn_Inserccion.UseVisualStyleBackColor = true;
            this.Btn_Inserccion.Click += new System.EventHandler(this.Btn_Inserccion_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(419, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Salida:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Ingresar números:";
            // 
            // Caja_MostrarIns
            // 
            this.Caja_MostrarIns.Enabled = false;
            this.Caja_MostrarIns.Location = new System.Drawing.Point(376, 64);
            this.Caja_MostrarIns.Name = "Caja_MostrarIns";
            this.Caja_MostrarIns.Size = new System.Drawing.Size(135, 20);
            this.Caja_MostrarIns.TabIndex = 1;
            // 
            // Caja_Inserccion
            // 
            this.Caja_Inserccion.Location = new System.Drawing.Point(40, 64);
            this.Caja_Inserccion.Name = "Caja_Inserccion";
            this.Caja_Inserccion.Size = new System.Drawing.Size(135, 20);
            this.Caja_Inserccion.TabIndex = 0;
            this.Caja_Inserccion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_Inserccion_KeyPress);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Btn_Seleccion);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.Caja_MostrarSel);
            this.groupBox3.Controls.Add(this.Caja_Seleccion);
            this.groupBox3.Location = new System.Drawing.Point(127, 316);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(569, 118);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Método Selección";
            // 
            // Btn_Seleccion
            // 
            this.Btn_Seleccion.Location = new System.Drawing.Point(199, 89);
            this.Btn_Seleccion.Name = "Btn_Seleccion";
            this.Btn_Seleccion.Size = new System.Drawing.Size(147, 23);
            this.Btn_Seleccion.TabIndex = 7;
            this.Btn_Seleccion.Text = "Orden Selección";
            this.Btn_Seleccion.UseVisualStyleBackColor = true;
            this.Btn_Seleccion.Click += new System.EventHandler(this.Btn_Seleccion_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(419, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 16);
            this.label7.TabIndex = 5;
            this.label7.Text = "Salida:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(37, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ingresar números:";
            // 
            // Caja_MostrarSel
            // 
            this.Caja_MostrarSel.Enabled = false;
            this.Caja_MostrarSel.Location = new System.Drawing.Point(376, 62);
            this.Caja_MostrarSel.Name = "Caja_MostrarSel";
            this.Caja_MostrarSel.Size = new System.Drawing.Size(135, 20);
            this.Caja_MostrarSel.TabIndex = 1;
            // 
            // Caja_Seleccion
            // 
            this.Caja_Seleccion.Location = new System.Drawing.Point(40, 62);
            this.Caja_Seleccion.Name = "Caja_Seleccion";
            this.Caja_Seleccion.Size = new System.Drawing.Size(135, 20);
            this.Caja_Seleccion.TabIndex = 0;
            this.Caja_Seleccion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_Seleccion_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(620, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(168, 19);
            this.label9.TabIndex = 3;
            this.label9.Text = "Created by Happy Life";
            // 
            // Semana6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Semana6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Semana 6";
            this.Load += new System.EventHandler(this.Semana6_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Caja_MostrarBur;
        private System.Windows.Forms.TextBox Caja_Burbuja;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Caja_MostrarIns;
        private System.Windows.Forms.TextBox Caja_Inserccion;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox Caja_MostrarSel;
        private System.Windows.Forms.TextBox Caja_Seleccion;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Btn_Burbuja;
        private System.Windows.Forms.Button Btn_Inserccion;
        private System.Windows.Forms.Button Btn_Seleccion;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}