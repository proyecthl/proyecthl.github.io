﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormProyectSemana14
{
    public partial class Semana3 : Form
    {
        public Semana3()
        {
            InitializeComponent();
        }

        private void Semana3_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel1.LinkVisited = true;
            System.Diagnostics.Process.Start("https://github.com/hluciana");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel2.LinkVisited = true;
            System.Diagnostics.Process.Start("https://discord.gg/tGSaBjXqGB");
        }

        private void ref1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ref1.LinkVisited = true;
            System.Diagnostics.Process.Start("https://www.discoduroderoer.es/generar-numeros-aleatorios-con-c-sharp/");
        }

        private void ref2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ref2.LinkVisited = true;
            System.Diagnostics.Process.Start("https://es.stackoverflow.com/questions/517091/control-de-excepciones");
        }

        private void ref3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ref3.LinkVisited = true;
            System.Diagnostics.Process.Start("https://stackoverflow.com/questions/11947314/how-to-center-align-the-title-bar-text-in-windows-form");
        }

        private void ref4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ref4.LinkVisited = true;
            System.Diagnostics.Process.Start("https://www.youtube.com/watch?v=xoYiBLggBq8");
        }

        private void ref5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ref5.LinkVisited = true;
            System.Diagnostics.Process.Start("https://www.youtube.com/watch?v=vq9RKOXMsnE");
        }
    }
}
