﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormProyectSemana14
{
    public partial class Semana10 : Form
    {
        public Semana10()
        {
            InitializeComponent();
        }

        private void Semana10_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
        }

        private void Caja_Inicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Caja_Final_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Caja_Cantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Btn_Mostrar_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_Inicio.Text) | String.IsNullOrEmpty(Caja_Final.Text) | String.IsNullOrEmpty(Caja_Cantidad.Text))
            {
                MessageBox.Show("No puede estar vacío los textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                Caja_Salida.Text = "";
                Random rdm = new Random();
                List<int> num = new List<int>();

                for (int i = 0; i < int.Parse(Caja_Cantidad.Text); i++)
                {
                    num.Add(rdm.Next(int.Parse(Caja_Inicio.Text), int.Parse(Caja_Final.Text) + 1));
                }

                for (int i = 0; i < num.Count(); i++)
                {
                    Caja_Salida.Text += num[i] + " ";
                }

                num.Clear();
            }
        }
    }
}
