﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormProyectSemana14
{
    public partial class Semana9 : Form
    {
        public Semana9()
        {
            InitializeComponent();
        }

        private void Semana9_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
        }

        private void Btn_Sumar_Click(object sender, EventArgs e)
        {
            try
            {
                int num1 = int.Parse(Caja_Sum1.Text);
                int num2 = int.Parse(Caja_Sum2.Text);
                Caja_Salida.Text = (num1 + num2).ToString();
            } catch
            {
                MessageBox.Show("Solo debes ingresar números!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
