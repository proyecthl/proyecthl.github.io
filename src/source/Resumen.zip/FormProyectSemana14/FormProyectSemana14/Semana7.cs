﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormProyectSemana14
{
    public partial class Semana7 : Form
    {
        public Semana7()
        {
            InitializeComponent();
        }

        private void Semana7_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
        }

        private void Caja_RegistrarSec_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 43 || e.KeyChar >= 45 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        public string regSec;
        public string[] regSecEx;
        public int[] regSecInt;
        public string mostrarSec;
        public int cont;

        private void Btn_RegistrarSec_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_RegistrarSec.Text))
            {
                MessageBox.Show("No puedes registrar elementos vacios!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                mostrarSec = "";
                regSec = Caja_RegistrarSec.Text;
                regSecEx = regSec.Split(',');
                regSecInt = new int[regSecEx.Length];

                for (int i = 0; i < regSecInt.Length; i++)
                {
                    regSecInt[i] = int.Parse(regSecEx[i]);
                }

                for (int i = 0; i < regSecInt.Length; i++)
                {
                    mostrarSec += regSecInt[i] + " ";
                }
                cont++;
                MessageBox.Show(mostrarSec,"Números",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }

        private void Caja_BuscarSec_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Btn_BuscarSec_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_BuscarSec.Text))
            {
                MessageBox.Show("No puede estar vacío el textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                if (cont == 0)
                {
                    MessageBox.Show("Parece que no registraste números...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                } else
                {
                    string secuencial = Caja_BuscarSec.Text;
                    int acc = 0;

                    for (int i = 0; i < regSecInt.Length; i++)
                    {
                        if (int.Parse(secuencial) == regSecInt[i])
                        {
                            MessageBox.Show("Posición: " + i, "Número encontrado!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            acc++;
                            break;
                        }
                    }

                    if (acc == 0)
                    {
                        MessageBox.Show("El número no se encontró!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void Caja_RegistrarBin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 43 || e.KeyChar >= 45 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        public string regBin;
        public string[] regBinEx;
        public int[] regBinInt;
        public string mostrarBin;
        public int cont2;

        private void Btn_RegistrarBin_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_RegistrarBin.Text))
            {
                MessageBox.Show("No puedes registrar elementos vacios!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                mostrarBin = "";
                regBin = Caja_RegistrarBin.Text;
                regBinEx = regBin.Split(',');
                regBinInt = new int[regBinEx.Length];

                for (int i = 0; i < regBinInt.Length; i++)
                {
                    regBinInt[i] = int.Parse(regBinEx[i]);
                }

                Array.Sort(regBinInt);
                Caja_RegistrarBin.Text = "";

                for (int i = 0; i < regBinInt.Length; i++)
                {
                    mostrarBin += regBinInt[i] + " ";
                    Caja_RegistrarBin.Text += regBinInt[i] + ",";
                }
                cont2++;
                MessageBox.Show(mostrarBin, "Números", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Caja_BuscarBin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Btn_BuscarBin_Click(object sender, EventArgs e)
        {
            string binaria;
            if (String.IsNullOrEmpty(Caja_BuscarBin.Text))
            {
                MessageBox.Show("No puede estar vacío el textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (cont2 == 0)
                {
                    MessageBox.Show("Parece que no registraste números...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    binaria = Caja_BuscarBin.Text;
                    int inf = 0;
                    int centro = 0;
                    int sup = regBinInt.Length - 1;
                    bool found = false;

                    while (inf <= sup)
                    {
                        centro = (sup + inf) / 2;
                        if (regBinInt[centro] == int.Parse(binaria))
                        {
                            found = true;
                            break;
                        }
                        else if (int.Parse(binaria) < regBinInt[centro])
                        {
                            sup = centro - 1;
                        }
                        else
                        {
                            inf = centro + 1;
                        }
                    }

                    if (found == true)
                    {
                        MessageBox.Show("Posicion: " + centro, "Número encontrado!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("El número no se encontró!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }
    }
}
