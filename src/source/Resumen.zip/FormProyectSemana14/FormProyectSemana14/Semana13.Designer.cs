﻿namespace FormProyectSemana14
{
    partial class Semana13
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Semana13));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Caja_NombreDel = new System.Windows.Forms.TextBox();
            this.Caja_NombreMov = new System.Windows.Forms.TextBox();
            this.Btn_Origen = new System.Windows.Forms.Button();
            this.Btn_Destino = new System.Windows.Forms.Button();
            this.Btn_Mover = new System.Windows.Forms.Button();
            this.Btn_Eliminar = new System.Windows.Forms.Button();
            this.Btn_Ubicacion = new System.Windows.Forms.Button();
            this.LblOrigen = new System.Windows.Forms.Label();
            this.LblDestino = new System.Windows.Forms.Label();
            this.LblUbicacion = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(216, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(389, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Archivos de acceso parte 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(620, 422);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Created by Happy Life";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Location = new System.Drawing.Point(119, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(573, 361);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Archivos:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Salmon;
            this.panel1.Controls.Add(this.LblDestino);
            this.panel1.Controls.Add(this.LblOrigen);
            this.panel1.Controls.Add(this.Btn_Mover);
            this.panel1.Controls.Add(this.Btn_Destino);
            this.panel1.Controls.Add(this.Btn_Origen);
            this.panel1.Controls.Add(this.Caja_NombreMov);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(45, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(456, 139);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.panel2.Controls.Add(this.LblUbicacion);
            this.panel2.Controls.Add(this.Btn_Ubicacion);
            this.panel2.Controls.Add(this.Btn_Eliminar);
            this.panel2.Controls.Add(this.Caja_NombreDel);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(45, 214);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(456, 132);
            this.panel2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(224, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mover:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(223, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Eliminar:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(69, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Nombre:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(69, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "Nombre:";
            // 
            // Caja_NombreDel
            // 
            this.Caja_NombreDel.Location = new System.Drawing.Point(58, 59);
            this.Caja_NombreDel.Name = "Caja_NombreDel";
            this.Caja_NombreDel.Size = new System.Drawing.Size(100, 20);
            this.Caja_NombreDel.TabIndex = 1;
            // 
            // Caja_NombreMov
            // 
            this.Caja_NombreMov.Location = new System.Drawing.Point(55, 50);
            this.Caja_NombreMov.Name = "Caja_NombreMov";
            this.Caja_NombreMov.Size = new System.Drawing.Size(100, 20);
            this.Caja_NombreMov.TabIndex = 1;
            // 
            // Btn_Origen
            // 
            this.Btn_Origen.Location = new System.Drawing.Point(258, 14);
            this.Btn_Origen.Name = "Btn_Origen";
            this.Btn_Origen.Size = new System.Drawing.Size(113, 23);
            this.Btn_Origen.TabIndex = 2;
            this.Btn_Origen.Text = "Origen";
            this.Btn_Origen.UseVisualStyleBackColor = true;
            this.Btn_Origen.Click += new System.EventHandler(this.Btn_Origen_Click);
            // 
            // Btn_Destino
            // 
            this.Btn_Destino.Location = new System.Drawing.Point(258, 59);
            this.Btn_Destino.Name = "Btn_Destino";
            this.Btn_Destino.Size = new System.Drawing.Size(113, 23);
            this.Btn_Destino.TabIndex = 3;
            this.Btn_Destino.Text = "Destino";
            this.Btn_Destino.UseVisualStyleBackColor = true;
            this.Btn_Destino.Click += new System.EventHandler(this.Btn_Destino_Click);
            // 
            // Btn_Mover
            // 
            this.Btn_Mover.Location = new System.Drawing.Point(58, 102);
            this.Btn_Mover.Name = "Btn_Mover";
            this.Btn_Mover.Size = new System.Drawing.Size(313, 22);
            this.Btn_Mover.TabIndex = 4;
            this.Btn_Mover.Text = "Mover";
            this.Btn_Mover.UseVisualStyleBackColor = true;
            this.Btn_Mover.Click += new System.EventHandler(this.Btn_Mover_Click);
            // 
            // Btn_Eliminar
            // 
            this.Btn_Eliminar.Location = new System.Drawing.Point(58, 96);
            this.Btn_Eliminar.Name = "Btn_Eliminar";
            this.Btn_Eliminar.Size = new System.Drawing.Size(313, 23);
            this.Btn_Eliminar.TabIndex = 2;
            this.Btn_Eliminar.Text = "Eliminar";
            this.Btn_Eliminar.UseVisualStyleBackColor = true;
            this.Btn_Eliminar.Click += new System.EventHandler(this.Btn_Eliminar_Click);
            // 
            // Btn_Ubicacion
            // 
            this.Btn_Ubicacion.Location = new System.Drawing.Point(258, 42);
            this.Btn_Ubicacion.Name = "Btn_Ubicacion";
            this.Btn_Ubicacion.Size = new System.Drawing.Size(113, 23);
            this.Btn_Ubicacion.TabIndex = 3;
            this.Btn_Ubicacion.Text = "Ubicación";
            this.Btn_Ubicacion.UseVisualStyleBackColor = true;
            this.Btn_Ubicacion.Click += new System.EventHandler(this.Btn_Ubicacion_Click);
            // 
            // LblOrigen
            // 
            this.LblOrigen.AutoSize = true;
            this.LblOrigen.Location = new System.Drawing.Point(220, 40);
            this.LblOrigen.Name = "LblOrigen";
            this.LblOrigen.Size = new System.Drawing.Size(10, 13);
            this.LblOrigen.TabIndex = 5;
            this.LblOrigen.Text = ".";
            // 
            // LblDestino
            // 
            this.LblDestino.AutoSize = true;
            this.LblDestino.Location = new System.Drawing.Point(220, 86);
            this.LblDestino.Name = "LblDestino";
            this.LblDestino.Size = new System.Drawing.Size(10, 13);
            this.LblDestino.TabIndex = 6;
            this.LblDestino.Text = ".";
            // 
            // LblUbicacion
            // 
            this.LblUbicacion.AutoSize = true;
            this.LblUbicacion.Location = new System.Drawing.Point(220, 80);
            this.LblUbicacion.Name = "LblUbicacion";
            this.LblUbicacion.Size = new System.Drawing.Size(10, 13);
            this.LblUbicacion.TabIndex = 4;
            this.LblUbicacion.Text = ".";
            // 
            // Semana13
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Semana13";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Semana 13";
            this.Load += new System.EventHandler(this.Semana13_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button Btn_Ubicacion;
        private System.Windows.Forms.Button Btn_Eliminar;
        private System.Windows.Forms.TextBox Caja_NombreDel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Btn_Mover;
        private System.Windows.Forms.Button Btn_Destino;
        private System.Windows.Forms.Button Btn_Origen;
        private System.Windows.Forms.TextBox Caja_NombreMov;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LblUbicacion;
        private System.Windows.Forms.Label LblDestino;
        private System.Windows.Forms.Label LblOrigen;
    }
}