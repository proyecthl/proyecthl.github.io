﻿namespace FormProyectSemana14
{
    partial class Semana10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Semana10));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Caja_Cantidad = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Caja_Salida = new System.Windows.Forms.RichTextBox();
            this.Btn_Mostrar = new System.Windows.Forms.Button();
            this.Caja_Final = new System.Windows.Forms.TextBox();
            this.Caja_Inicio = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(357, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Listas";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Caja_Cantidad);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Caja_Salida);
            this.groupBox1.Controls.Add(this.Btn_Mostrar);
            this.groupBox1.Controls.Add(this.Caja_Final);
            this.groupBox1.Controls.Add(this.Caja_Inicio);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(151, 106);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(507, 279);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lista de Números Random";
            // 
            // Caja_Cantidad
            // 
            this.Caja_Cantidad.Location = new System.Drawing.Point(52, 197);
            this.Caja_Cantidad.Name = "Caja_Cantidad";
            this.Caja_Cantidad.Size = new System.Drawing.Size(100, 20);
            this.Caja_Cantidad.TabIndex = 8;
            this.Caja_Cantidad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_Cantidad_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(63, 168);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Cantidad:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(301, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Números:";
            // 
            // Caja_Salida
            // 
            this.Caja_Salida.Location = new System.Drawing.Point(256, 68);
            this.Caja_Salida.Name = "Caja_Salida";
            this.Caja_Salida.Size = new System.Drawing.Size(169, 189);
            this.Caja_Salida.TabIndex = 5;
            this.Caja_Salida.Text = "Cuidado con poner en cantidad muchos números, el programa podria demorar mucho y " +
    "trabar tu maquina!";
            // 
            // Btn_Mostrar
            // 
            this.Btn_Mostrar.Location = new System.Drawing.Point(52, 234);
            this.Btn_Mostrar.Name = "Btn_Mostrar";
            this.Btn_Mostrar.Size = new System.Drawing.Size(100, 23);
            this.Btn_Mostrar.TabIndex = 4;
            this.Btn_Mostrar.Text = "Mostrar";
            this.Btn_Mostrar.UseVisualStyleBackColor = true;
            this.Btn_Mostrar.Click += new System.EventHandler(this.Btn_Mostrar_Click);
            // 
            // Caja_Final
            // 
            this.Caja_Final.Location = new System.Drawing.Point(52, 131);
            this.Caja_Final.Name = "Caja_Final";
            this.Caja_Final.Size = new System.Drawing.Size(100, 20);
            this.Caja_Final.TabIndex = 3;
            this.Caja_Final.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_Final_KeyPress);
            // 
            // Caja_Inicio
            // 
            this.Caja_Inicio.Location = new System.Drawing.Point(52, 68);
            this.Caja_Inicio.Name = "Caja_Inicio";
            this.Caja_Inicio.Size = new System.Drawing.Size(100, 20);
            this.Caja_Inicio.TabIndex = 2;
            this.Caja_Inicio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_Inicio_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(81, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Final:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(81, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Inicio:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(620, 422);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 19);
            this.label6.TabIndex = 2;
            this.label6.Text = "Created by Happy Life";
            // 
            // Semana10
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Semana10";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Semana 10";
            this.Load += new System.EventHandler(this.Semana10_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox Caja_Salida;
        private System.Windows.Forms.Button Btn_Mostrar;
        private System.Windows.Forms.TextBox Caja_Final;
        private System.Windows.Forms.TextBox Caja_Inicio;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Caja_Cantidad;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}