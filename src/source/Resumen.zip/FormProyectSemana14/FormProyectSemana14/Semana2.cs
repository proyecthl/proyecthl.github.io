﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormProyectSemana14
{
    public partial class Semana2 : Form
    {
        public Semana2()
        {
            InitializeComponent();
        }

        private void Semana2_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
        }

        private void Btn_Juntar_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja1.Text) | String.IsNullOrEmpty(Caja2.Text) | String.IsNullOrEmpty(Caja3.Text) | String.IsNullOrEmpty(Caja4.Text))
            {
                MessageBox.Show("No puede estar vacío los textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                string mostrar = "";
                var hombres = new Personas<string>() { Caja1.Text, Caja2.Text };
                var mujeres = new Personas<string>() { Caja3.Text, Caja4.Text };
                var personas = hombres + mujeres;

                personas.ForEach(elem => mostrar += elem + " ");
                MessageBox.Show(mostrar, "Personas: ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private class Personas<T> : List<T>
        {
            public static Personas<T> operator +(Personas<T> h,Personas<T> m)
            {
                var todos = new Personas<T>();
                h.ForEach(el => todos.Add(el));
                m.ForEach(ele => todos.Add(ele));
                return todos;
            }
        }
    }
}
