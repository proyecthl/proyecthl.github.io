﻿namespace FormProyectSemana14
{
    partial class Semana8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Semana8));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Caja_MostrarDes = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Btn_Des = new System.Windows.Forms.Button();
            this.Caja_Des = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Caja_MostrarVol = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Btn_Vol = new System.Windows.Forms.Button();
            this.Caja_Vol = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(322, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Recursividad";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Caja_MostrarDes);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Btn_Des);
            this.groupBox1.Controls.Add(this.Caja_Des);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(162, 68);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(502, 168);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Números Descendente:";
            // 
            // Caja_MostrarDes
            // 
            this.Caja_MostrarDes.Location = new System.Drawing.Point(304, 51);
            this.Caja_MostrarDes.Name = "Caja_MostrarDes";
            this.Caja_MostrarDes.Size = new System.Drawing.Size(116, 80);
            this.Caja_MostrarDes.TabIndex = 4;
            this.Caja_MostrarDes.Text = "Cuidado con poner números demasiado grandes, el programa podria demorar mucho y t" +
    "rabar tu maquina!";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(330, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Salida:";
            // 
            // Btn_Des
            // 
            this.Btn_Des.Location = new System.Drawing.Point(41, 108);
            this.Btn_Des.Name = "Btn_Des";
            this.Btn_Des.Size = new System.Drawing.Size(114, 23);
            this.Btn_Des.TabIndex = 2;
            this.Btn_Des.Text = "Mostrar";
            this.Btn_Des.UseVisualStyleBackColor = true;
            this.Btn_Des.Click += new System.EventHandler(this.Btn_Des_Click);
            // 
            // Caja_Des
            // 
            this.Caja_Des.Location = new System.Drawing.Point(41, 68);
            this.Caja_Des.Name = "Caja_Des";
            this.Caja_Des.Size = new System.Drawing.Size(114, 20);
            this.Caja_Des.TabIndex = 1;
            this.Caja_Des.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_Des_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(38, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Ingresar Número:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Caja_MostrarVol);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.Btn_Vol);
            this.groupBox2.Controls.Add(this.Caja_Vol);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(162, 250);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(502, 173);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Voltear Texto:";
            // 
            // Caja_MostrarVol
            // 
            this.Caja_MostrarVol.Location = new System.Drawing.Point(304, 58);
            this.Caja_MostrarVol.Name = "Caja_MostrarVol";
            this.Caja_MostrarVol.Size = new System.Drawing.Size(116, 104);
            this.Caja_MostrarVol.TabIndex = 4;
            this.Caja_MostrarVol.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(330, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 16);
            this.label5.TabIndex = 3;
            this.label5.Text = "Salida:";
            // 
            // Btn_Vol
            // 
            this.Btn_Vol.Location = new System.Drawing.Point(41, 139);
            this.Btn_Vol.Name = "Btn_Vol";
            this.Btn_Vol.Size = new System.Drawing.Size(114, 23);
            this.Btn_Vol.TabIndex = 2;
            this.Btn_Vol.Text = "Mostrar";
            this.Btn_Vol.UseVisualStyleBackColor = true;
            this.Btn_Vol.Click += new System.EventHandler(this.Btn_Vol_Click);
            // 
            // Caja_Vol
            // 
            this.Caja_Vol.Location = new System.Drawing.Point(41, 58);
            this.Caja_Vol.Name = "Caja_Vol";
            this.Caja_Vol.Size = new System.Drawing.Size(114, 75);
            this.Caja_Vol.TabIndex = 1;
            this.Caja_Vol.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(38, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Ingresar Texto:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(620, 426);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 19);
            this.label6.TabIndex = 3;
            this.label6.Text = "Created by Happy Life";
            // 
            // Semana8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Semana8";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Semana 8";
            this.Load += new System.EventHandler(this.Semana8_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox Caja_MostrarDes;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Btn_Des;
        private System.Windows.Forms.TextBox Caja_Des;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox Caja_MostrarVol;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Btn_Vol;
        private System.Windows.Forms.RichTextBox Caja_Vol;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
    }
}