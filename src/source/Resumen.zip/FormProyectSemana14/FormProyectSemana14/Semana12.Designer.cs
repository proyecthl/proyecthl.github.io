﻿namespace FormProyectSemana14
{
    partial class Semana12
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Semana12));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Btn_Leer = new System.Windows.Forms.Button();
            this.Caja_Salida = new System.Windows.Forms.RichTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Btn_Buscar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Caja_Posicion = new System.Windows.Forms.TextBox();
            this.Caja_Acceso = new System.Windows.Forms.RichTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Btn_Crear = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.LblSalida = new System.Windows.Forms.Label();
            this.Caja_Nombre = new System.Windows.Forms.TextBox();
            this.Btn_Ubicacion = new System.Windows.Forms.Button();
            this.Caja_Contenido = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(268, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(286, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Archivos de acceso";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(620, 422);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Created by Happy Life";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Location = new System.Drawing.Point(149, 74);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(519, 345);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Archivos:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.NavajoWhite;
            this.panel3.Controls.Add(this.Btn_Leer);
            this.panel3.Controls.Add(this.Caja_Salida);
            this.panel3.Location = new System.Drawing.Point(352, 19);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(144, 320);
            this.panel3.TabIndex = 11;
            // 
            // Btn_Leer
            // 
            this.Btn_Leer.Location = new System.Drawing.Point(13, 265);
            this.Btn_Leer.Name = "Btn_Leer";
            this.Btn_Leer.Size = new System.Drawing.Size(118, 40);
            this.Btn_Leer.TabIndex = 11;
            this.Btn_Leer.Text = "Leer";
            this.Btn_Leer.UseVisualStyleBackColor = true;
            this.Btn_Leer.Click += new System.EventHandler(this.Btn_Leer_Click);
            // 
            // Caja_Salida
            // 
            this.Caja_Salida.Location = new System.Drawing.Point(13, 30);
            this.Caja_Salida.Name = "Caja_Salida";
            this.Caja_Salida.Size = new System.Drawing.Size(118, 207);
            this.Caja_Salida.TabIndex = 10;
            this.Caja_Salida.Text = "";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.BurlyWood;
            this.panel2.Controls.Add(this.Btn_Buscar);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.Caja_Posicion);
            this.panel2.Controls.Add(this.Caja_Acceso);
            this.panel2.Location = new System.Drawing.Point(196, 19);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(141, 320);
            this.panel2.TabIndex = 11;
            // 
            // Btn_Buscar
            // 
            this.Btn_Buscar.Location = new System.Drawing.Point(19, 265);
            this.Btn_Buscar.Name = "Btn_Buscar";
            this.Btn_Buscar.Size = new System.Drawing.Size(100, 40);
            this.Btn_Buscar.TabIndex = 9;
            this.Btn_Buscar.Text = "Buscar";
            this.Btn_Buscar.UseVisualStyleBackColor = true;
            this.Btn_Buscar.Click += new System.EventHandler(this.Btn_Buscar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Acceso aleatorio:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(34, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "Posición:";
            // 
            // Caja_Posicion
            // 
            this.Caja_Posicion.Location = new System.Drawing.Point(19, 62);
            this.Caja_Posicion.Name = "Caja_Posicion";
            this.Caja_Posicion.Size = new System.Drawing.Size(100, 20);
            this.Caja_Posicion.TabIndex = 7;
            // 
            // Caja_Acceso
            // 
            this.Caja_Acceso.Location = new System.Drawing.Point(19, 134);
            this.Caja_Acceso.Name = "Caja_Acceso";
            this.Caja_Acceso.Size = new System.Drawing.Size(100, 103);
            this.Caja_Acceso.TabIndex = 8;
            this.Caja_Acceso.Text = "";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Peru;
            this.panel1.Controls.Add(this.Btn_Crear);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.LblSalida);
            this.panel1.Controls.Add(this.Caja_Nombre);
            this.panel1.Controls.Add(this.Btn_Ubicacion);
            this.panel1.Controls.Add(this.Caja_Contenido);
            this.panel1.Location = new System.Drawing.Point(31, 19);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(144, 320);
            this.panel1.TabIndex = 12;
            // 
            // Btn_Crear
            // 
            this.Btn_Crear.Location = new System.Drawing.Point(23, 265);
            this.Btn_Crear.Name = "Btn_Crear";
            this.Btn_Crear.Size = new System.Drawing.Size(100, 40);
            this.Btn_Crear.TabIndex = 2;
            this.Btn_Crear.Text = "Crear";
            this.Btn_Crear.UseVisualStyleBackColor = true;
            this.Btn_Crear.Click += new System.EventHandler(this.Btn_Crear_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(43, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Nombre:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 103);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 16);
            this.label6.TabIndex = 4;
            this.label6.Text = "Contenido:";
            // 
            // LblSalida
            // 
            this.LblSalida.AutoSize = true;
            this.LblSalida.Location = new System.Drawing.Point(3, 242);
            this.LblSalida.Name = "LblSalida";
            this.LblSalida.Size = new System.Drawing.Size(10, 13);
            this.LblSalida.TabIndex = 4;
            this.LblSalida.Text = ".";
            // 
            // Caja_Nombre
            // 
            this.Caja_Nombre.Location = new System.Drawing.Point(23, 60);
            this.Caja_Nombre.Name = "Caja_Nombre";
            this.Caja_Nombre.Size = new System.Drawing.Size(100, 20);
            this.Caja_Nombre.TabIndex = 1;
            // 
            // Btn_Ubicacion
            // 
            this.Btn_Ubicacion.Location = new System.Drawing.Point(23, 208);
            this.Btn_Ubicacion.Name = "Btn_Ubicacion";
            this.Btn_Ubicacion.Size = new System.Drawing.Size(100, 29);
            this.Btn_Ubicacion.TabIndex = 3;
            this.Btn_Ubicacion.Text = "Ubicación";
            this.Btn_Ubicacion.UseVisualStyleBackColor = true;
            this.Btn_Ubicacion.Click += new System.EventHandler(this.Btn_Ubicacion_Click);
            // 
            // Caja_Contenido
            // 
            this.Caja_Contenido.Location = new System.Drawing.Point(23, 134);
            this.Caja_Contenido.Name = "Caja_Contenido";
            this.Caja_Contenido.Size = new System.Drawing.Size(100, 68);
            this.Caja_Contenido.TabIndex = 3;
            this.Caja_Contenido.Text = "";
            // 
            // Semana12
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Semana12";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Semana 12";
            this.Load += new System.EventHandler(this.Semana12_Load);
            this.groupBox1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Btn_Ubicacion;
        private System.Windows.Forms.Button Btn_Crear;
        private System.Windows.Forms.TextBox Caja_Nombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label LblSalida;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Btn_Buscar;
        private System.Windows.Forms.RichTextBox Caja_Acceso;
        private System.Windows.Forms.TextBox Caja_Posicion;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox Caja_Contenido;
        private System.Windows.Forms.Button Btn_Leer;
        private System.Windows.Forms.RichTextBox Caja_Salida;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
    }
}