﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormProyectSemana14
{
    public partial class Semana4 : Form
    {
        public Semana4()
        {
            InitializeComponent();
        }

        private void Semana4_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
            LblPersonaje.Text = "";
        }

        private void Caja_Ataque_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Caja_Vida_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Caja_Resistencia_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Btn_Crear_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_Nombre.Text) | String.IsNullOrEmpty(Caja_Ataque.Text) | String.IsNullOrEmpty(Caja_Vida.Text) | String.IsNullOrEmpty(Caja_Resistencia.Text))
            {
                MessageBox.Show("No puede estar vacío los textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                LblPersonaje.Text = "";
                Personaje per = new Personaje(Caja_Nombre.Text,int.Parse(Caja_Ataque.Text),int.Parse(Caja_Vida.Text),int.Parse(Caja_Resistencia.Text));
                LblPersonaje.Text = per.Info();
            }
        }
    }

    public class Personaje
    {
        private string nombre;
        private int ataque;
        private int vida;
        private int resistencia;

        public Personaje(string nom,int ataq,int vid,int resist)
        {
            this.nombre = nom;
            this.ataque = ataq;
            this.vida = vid;
            this.resistencia = resist;
        }

        public string Info()
        {
            return "Nombre: " + this.nombre + "\n\nAtaque: " + this.ataque + "\n\nVida: " + this.vida + "\n\nResistencia: " + this.resistencia;
        }
    }
}
