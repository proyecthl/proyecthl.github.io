﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace FormProyectSemana14
{
    public partial class Semana12 : Form
    {
        public Semana12()
        {
            InitializeComponent();
        }

        private void Semana12_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
        }

        public string path = String.Empty;

        private void Btn_Ubicacion_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog ruta = new FolderBrowserDialog();

            if (ruta.ShowDialog() == DialogResult.OK)
            {
                path = ruta.SelectedPath;
            }
            LblSalida.Text = path;
        }

        private void Btn_Crear_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_Nombre.Text) | String.IsNullOrEmpty(Caja_Contenido.Text))
            {
                MessageBox.Show("Porfavor completa todos los campos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            } else
            {
                try
                {
                    if(path == String.Empty)
                    {
                        MessageBox.Show("Porfavor selecciona una ubicación!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    } else
                    {
                        if (File.Exists(path + "\\" + Caja_Nombre.Text + ".txt"))
                        {
                            using (var fs = new FileStream(path + "\\" + Caja_Nombre.Text + ".txt",FileMode.Append))
                            {
                                using(var sw = new StreamWriter(fs))
                                {
                                    sw.WriteLine(Caja_Contenido.Text);
                                }
                            }
                            MessageBox.Show("Guardado con exito!", "Info", MessageBoxButtons.OK);
                        } else
                        {
                            using(FileStream fs = new FileStream(path + "\\" + Caja_Nombre.Text + ".txt", FileMode.Create, FileAccess.Write))
                            {
                                byte[] buffer = Encoding.Default.GetBytes(Caja_Contenido.Text);
                                fs.Write(buffer, 0, buffer.Length);
                                fs.Flush();
                                fs.Close();
                            }
                            MessageBox.Show("Guardado con exito!", "Info", MessageBoxButtons.OK);
                        }
                    }
                } catch
                {
                    MessageBox.Show("Parece que hubo un error...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Btn_Buscar_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_Posicion.Text))
            {
                MessageBox.Show("Porfavor completa todos los campos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            } else
            {
                try
                {
                    if (File.Exists(path + "\\" + Caja_Nombre.Text + ".txt"))
                    {
                        Caja_Acceso.Text = "";
                        int nextByte;
                        using (FileStream fs = new FileStream(path + "\\" + Caja_Nombre.Text + ".txt", FileMode.Open, FileAccess.Read))
                        {
                            fs.Seek(Convert.ToInt32(Caja_Posicion.Text), SeekOrigin.Begin);
                            while ((nextByte = fs.ReadByte()) > 0)
                            {
                                Caja_Acceso.Text += (char)nextByte;
                            }
                        }
                    } else
                    {
                        MessageBox.Show("Parece que el archivo no existe...!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                } catch
                {
                    MessageBox.Show("Parece que hubo un error...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Btn_Leer_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(path + "\\" + Caja_Nombre.Text + ".txt"))
                {
                    using (var fs = new FileStream(path + "\\" + Caja_Nombre.Text + ".txt",FileMode.Open))
                    {
                        using (var read = new StreamReader(fs))
                        {
                            Caja_Salida.Text = "";
                            Caja_Salida.Text = read.ReadToEnd();
                        }
                    }
                } else
                {
                    MessageBox.Show("Parece que el archivo no existe...!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            } catch
            {
                MessageBox.Show("Parece que hubo un error...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
