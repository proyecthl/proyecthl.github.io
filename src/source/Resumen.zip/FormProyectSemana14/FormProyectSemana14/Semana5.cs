﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormProyectSemana14
{
    public partial class Semana5 : Form
    {
        public Semana5()
        {
            InitializeComponent();
        }

        private void Semana5_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
            LblUsuario.Text = "";
        }

        private void Caja_Edad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Caja_Telefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Btn_Registrar_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_Nombre.Text) | String.IsNullOrEmpty(Caja_Apellido.Text) | String.IsNullOrEmpty(Caja_Edad.Text) | String.IsNullOrEmpty(Caja_Telefono.Text))
            {
                MessageBox.Show("No puede estar vacío el textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                LblUsuario.Text = "";
                Usuario us = new Usuario();
                us.nombre = Caja_Nombre.Text;
                us.apellido = Caja_Apellido.Text;
                us.edad = int.Parse(Caja_Edad.Text);
                us.telefono = int.Parse(Caja_Telefono.Text);

                LblUsuario.Text = "Nombre: " + us.nombre + "\n\nApellido: " + us.apellido + "\n\nEdad: " + us.edad + "\n\nTeléfono: " + us.telefono;
            }
        }
    }

    public struct Usuario
    {
        public string nombre;
        public string apellido;
        public int edad;
        public int telefono;
    }
}
