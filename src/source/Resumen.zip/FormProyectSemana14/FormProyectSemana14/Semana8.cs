﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormProyectSemana14
{
    public partial class Semana8 : Form
    {
        public Semana8()
        {
            InitializeComponent();
        }

        private void Semana8_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
        }

        private void Caja_Des_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void Btn_Des_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_Des.Text))
            {
                MessageBox.Show("No puede estar vacío el textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int numDes = int.Parse(Caja_Des.Text);
                Caja_MostrarDes.Text = "";
                Descendente(numDes);

            }
        }

        private void Descendente(int x)
        {
            if (x > 0)
            {
                Caja_MostrarDes.Text += x + " ";
                Descendente(x - 1);
            }
            else
            {
                Caja_MostrarDes.Text += x.ToString();
            }
        }

        private void Btn_Vol_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Caja_Vol.Text))
            {
                MessageBox.Show("No puede estar vacío el textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string txtVol = Caja_Vol.Text;
                Caja_MostrarVol.Text = "";
                Caja_MostrarVol.Text = Voltear(txtVol);
            }
        }

        private string Voltear(string txt)
        {
            if (txt.Length <= 1)
            {
                return txt;
            }

            char first = txt[0];
            string res = txt.Substring(1);
            return Voltear(res) + first;
        }
    }
}
