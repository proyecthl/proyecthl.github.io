﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormProyectSemana14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }

            UpdateTextPosition();
        }

        private void Btn_Semana2_Click(object sender, EventArgs e)
        {
            Semana2 s2 = new Semana2();
            s2.Show();
        }

        private void Btn_Semana3_Click(object sender, EventArgs e)
        {
            Semana3 s3 = new Semana3();
            s3.Show();
        }

        private void Btn_Semana4_Click(object sender, EventArgs e)
        {
            Semana4 s4 = new Semana4();
            s4.Show();
        }

        private void Btn_Semana5_Click(object sender, EventArgs e)
        {
            Semana5 s5 = new Semana5();
            s5.Show();
        }

        private void Btn_Semana6_Click(object sender, EventArgs e)
        {
            Semana6 s6 = new Semana6();
            s6.Show();
        }

        private void Btn_Semana7_Click(object sender, EventArgs e)
        {
            Semana7 s7 = new Semana7();
            s7.Show();
        }

        private void Btn_Semana8_Click(object sender, EventArgs e)
        {
            Semana8 s8 = new Semana8();
            s8.Show();
        }

        private void Btn_Semana9_Click(object sender, EventArgs e)
        {
            Semana9 s9 = new Semana9();
            s9.Show();
        }

        private void Btn_Semana10_Click(object sender, EventArgs e)
        {
            Semana10 s10 = new Semana10();
            s10.Show();
        }

        private void Btn_Semana11_Click(object sender, EventArgs e)
        {
            Semana11 s11 = new Semana11();
            s11.Show();
        }

        private void Btn_Semana12_Click(object sender, EventArgs e)
        {
            Semana12 s12 = new Semana12();
            s12.Show();
        }

        private void Btn_Semana13_Click(object sender, EventArgs e)
        {
            Semana13 s13 = new Semana13();
            s13.Show();
        }
    }
}
