﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

// Namespace del proyecto donde se trabaja el form
namespace ProgramadoresVideoGames
{
    // Clase que hereda las propiedades del Form1 para nuestro código
    public partial class Form1 : Form
    {
        // Creando la clase poniendo como nombre clave la palabra var
        ProgramadoresVideoGames var = new ProgramadoresVideoGames();

        // Esto hará iniciar los componentes del proyecto
        public Form1()
        {
            InitializeComponent();
        }

        // Método del formulario cuando este cargado
        private void Form1_Load(object sender, EventArgs e)
        {
            // Método para centrar el título del Form
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }
            // Llamando al método de centrar texto
            UpdateTextPosition();
            // Cambiando el estilo del combobox para evitar que se escriba dentro
            Combo_Dias.DropDownStyle = ComboBoxStyle.DropDownList;
            // Poniendo en el combobox por defecto un día de la semana
            Combo_Dias.Text = "Lunes";
            // Poniendo la ubicación del archivo(guardar txt) vacío
            var.Path = String.Empty;
            // Poniendo datos(guardar txt) vacío
            var.Datos = String.Empty;
            // Variable para poner los números de registro(guardar txt)
            var.Acc = 0;
            // Dejando vacio el label de puntos finales
            Lbl_Total.Text = "";
        }

        // Método del boton registrar donde se motrará toda la info(juegos,días,resultado,puntos)
        private void Btn_Registrar_Click(object sender, EventArgs e)
        {
            // Comprobamos si el textbox de juegos esta vacío
            if (String.IsNullOrEmpty(Caja_juegos.Text) || Caja_juegos.Text[0] == ' ')
            {
                // Le mostramos un mensaje diciendo que complete el campo
                MessageBox.Show("Porfavor escribe un juego!","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            } else
            {
                // En caso el textbox este completo verificamos si uno de los checkbox esta seleccionado
                if (Check_Victoria.Checked == false && Check_Derrota.Checked == false)
                {
                    // Mostrar un mensaje para que seleccione uno de los dos
                    MessageBox.Show("Porfavor seleccione su resultado!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                } else
                {
                    // En caso todo se encuentre correcto
                    try
                    {
                        // En caso el checkbox de victoria se encuentre marcado
                        if (Check_Victoria.Checked == true)
                        {
                            // A la variable puntostotal le sumamos 100(clase)
                            var.PuntosTotal += 100;
                            // Llamamos un método de registro
                            Registro();

                        }
                        else
                        {
                            // En caso contrario(derrota)
                            // A la variable puntostotal le restamos 20(clase)
                            var.PuntosTotal -= 20;
                            // Llamamos un método de registro
                            Registro();
                        }
                    } catch
                    {
                        // Por si las dudas agregamos una excepción evitando algún problema extra
                        MessageBox.Show("Parece que hubo un error, intentalo de nuevo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // Método para registrar una vez verificado todo
        private void Registro()
        {
            try
            {
                // A la variable acc le sumamos 1(nos servirá para guardar en txt)
                var.Acc++;
                // Agregamos al listview su respectivo item
                ListViewItem fila = new ListViewItem(Combo_Dias.Text);
                fila.SubItems.Add(Caja_juegos.Text);
                fila.SubItems.Add(var.Resultado);
                fila.SubItems.Add((var.Puntos).ToString());
                listView1.Items.Add(fila);
                // Mostramos los puntos totales en su label que antes se encontraba vacío
                Lbl_Total.Text = (var.PuntosTotal).ToString();
                // Guardamos todos los datos en una variable(antes estaba vacía)
                 var.Datos += "Registro " + var.Acc + "\n" + "Día: " + Combo_Dias.Text + "\n" + "Juego: " + Caja_juegos.Text + "\n" + "Resultado: " + var.Resultado + "\n" + "Puntos Obtenidos: " + var.Puntos + "\n" + "Puntos Totales: " + var.PuntosTotal + "\n" + "------------------" + "\n";
            } catch
            {
                // Por si las dudas agregamos una excepción evitando algún problema extra
                MessageBox.Show("Parece que hubo un error, intentalo de nuevo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método del checkbox victoria
        private void Check_Victoria_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                // En caso seleccione victoria
                if (Check_Victoria.Checked == true)
                {
                    // Se desactiva el checkbox derrota
                    Check_Derrota.Enabled = false;
                    // La variable resultado sera "Victoria"
                    var.Resultado = "Victoria";
                    // Los puntos seran 100
                    var.Puntos = 100;
                }
                else
                {
                    // En caso no este seleccionado el checkbox derrota sera activado
                    Check_Derrota.Enabled = true;
                }
            } catch
            {
                // Por si las dudas agregamos una excepción evitando algún problema extra
                MessageBox.Show("Parece que hubo un error, intentalo de nuevo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método del checkbox derrota
        private void Check_Derrota_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                // En caso seleccione derrota
                if (Check_Derrota.Checked == true)
                {
                    // Se desactiva el checkbox victoria
                    Check_Victoria.Enabled = false;
                    // La variable resultado sera "Derrota"
                    var.Resultado = "Derrota";
                    // Los puntos seran -20
                    var.Puntos = -20;
                }
                else
                {
                    // En caso no este seleccionado el checkbox victoria sera activado
                    Check_Victoria.Enabled = true;
                }
            } catch
            {
                // Por si las dudas agregamos una excepción evitando algún problema extra
                MessageBox.Show("Parece que hubo un error, intentalo de nuevo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método del botón seleccionar ubicación(guardar txt)
        private void Btn_Ubicacion_Click(object sender, EventArgs e)
        {
            try
            {
                // Vamos a guardar la ruta seleccionado en la variable path(antes estaba vacía)
                FolderBrowserDialog ruta = new FolderBrowserDialog();

                if (ruta.ShowDialog() == DialogResult.OK)
                {
                     var.Path = ruta.SelectedPath;
                }
            } catch
            {
                // Por si las dudas agregamos una excepción evitando algún problema extra
                MessageBox.Show("Parece que hubo un error, intentalo de nuevo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método del boton guardar txt
        private void Btn_Guardar_Click(object sender, EventArgs e)
        {
            // Si la ubicación(path) esta vacía
            if (var.Path == String.Empty)
            {
                // Le indicamos que debe guardar una ubicación
                MessageBox.Show("Porfavor selecciona una ubicación!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                // Si los datos estan vacios(no registro ni un juego)
                if (var.Datos == String.Empty)
                {
                    // Le indicamos que debe registrar 
                    MessageBox.Show("Debes registrar al menos 1 dato!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                } else
                {
                    try
                    {
                        // Una vez haya guardados datos y seleccionado una ubicación lo que procedemos
                        // Es preguntarle si esta seguro que desea guardar en la ubicación que antes fue seleccionada
                        if (MessageBox.Show("Estas seguro que quieres guardarlo?" + "\n" + "Ubicación: " + var.Path, "Info", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            // En caso el archivo exista
                            if (File.Exists(var.Path + "\\" + "base_de_informacion.txt"))
                            {
                                // Lo eliminaremos y crearemos un nuevo(evitar repetidos)
                                File.Delete(var.Path + "\\" + "base_de_informacion.txt");
                                // Llamamos al metodo de crear y escribir archivo
                                ArchivoTexto();
                            }
                            else
                            {
                                // En caso el archivo no exista
                                // Llamamos al metodo de crear y escribir archivo
                                ArchivoTexto();
                            }
                        }
                    } catch
                    {
                        // Por si las dudas agregamos una excepción evitando algún problema extra
                        MessageBox.Show("Parece que hubo un error, intentalo de nuevo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // Método crear y escribir archivo
        private void ArchivoTexto()
        {
            try
            {
                // Usando streamwriter nos encargamos de guardar en bloc de notas, todos los datos que 
                string save = var.Path + "\\" + "base_de_informacion.txt";
                StreamWriter guardartxt = File.CreateText(save);
                guardartxt.Write(var.Datos);
                guardartxt.Flush();
                guardartxt.Close();
            } catch
            {
                // Por si las dudas agregamos una excepción evitando algún problema extra
                MessageBox.Show("Parece que hubo un error, intentalo de nuevo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    // Creando una clase que tendrá variables que nos ayudarán a lo largo del programa
    class ProgramadoresVideoGames
    {
        public string Resultado { get; set; }
        public string Path { get; set; }
        public string Datos { get; set; }
        public int Puntos { get; set; }
        public int PuntosTotal { get; set; }
        public int Acc { get; set; }
    }
}
