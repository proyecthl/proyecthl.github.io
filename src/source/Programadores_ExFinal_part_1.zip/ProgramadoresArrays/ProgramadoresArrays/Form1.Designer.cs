﻿namespace ProgramadoresArrays
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Btn_Ordenar = new System.Windows.Forms.Button();
            this.Btn_Registrar = new System.Windows.Forms.Button();
            this.Caja_Registrar = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Caja_Mostrar = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ingresar Texto:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Turquoise;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.Btn_Ordenar);
            this.panel1.Controls.Add(this.Btn_Registrar);
            this.panel1.Controls.Add(this.Caja_Registrar);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(159, 106);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(216, 241);
            this.panel1.TabIndex = 1;
            // 
            // Btn_Ordenar
            // 
            this.Btn_Ordenar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Ordenar.Location = new System.Drawing.Point(47, 169);
            this.Btn_Ordenar.Name = "Btn_Ordenar";
            this.Btn_Ordenar.Size = new System.Drawing.Size(122, 31);
            this.Btn_Ordenar.TabIndex = 3;
            this.Btn_Ordenar.Text = "Ordenar";
            this.Btn_Ordenar.UseVisualStyleBackColor = true;
            this.Btn_Ordenar.Click += new System.EventHandler(this.Btn_Ordenar_Click);
            // 
            // Btn_Registrar
            // 
            this.Btn_Registrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Registrar.Location = new System.Drawing.Point(47, 122);
            this.Btn_Registrar.Name = "Btn_Registrar";
            this.Btn_Registrar.Size = new System.Drawing.Size(122, 31);
            this.Btn_Registrar.TabIndex = 2;
            this.Btn_Registrar.Text = "Registrar";
            this.Btn_Registrar.UseVisualStyleBackColor = true;
            this.Btn_Registrar.Click += new System.EventHandler(this.Btn_Registrar_Click);
            // 
            // Caja_Registrar
            // 
            this.Caja_Registrar.Location = new System.Drawing.Point(47, 80);
            this.Caja_Registrar.Name = "Caja_Registrar";
            this.Caja_Registrar.Size = new System.Drawing.Size(122, 20);
            this.Caja_Registrar.TabIndex = 1;
            this.Caja_Registrar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Caja_Registrar_KeyPress);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Coral;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.Caja_Mostrar);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(465, 106);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(219, 241);
            this.panel2.TabIndex = 2;
            // 
            // Caja_Mostrar
            // 
            this.Caja_Mostrar.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Caja_Mostrar.Location = new System.Drawing.Point(44, 80);
            this.Caja_Mostrar.Name = "Caja_Mostrar";
            this.Caja_Mostrar.Size = new System.Drawing.Size(133, 120);
            this.Caja_Mostrar.TabIndex = 1;
            this.Caja_Mostrar.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(68, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "Salida:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Arreglos";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Btn_Ordenar;
        private System.Windows.Forms.Button Btn_Registrar;
        private System.Windows.Forms.TextBox Caja_Registrar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RichTextBox Caja_Mostrar;
        private System.Windows.Forms.Label label2;
    }
}

