﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Namespace del proyecto donde se trabaja el form
namespace ProgramadoresArrays
{
    // Clase que hereda las propiedades del Form1 para nuestro código
    public partial class Form1 : Form
    {
        // Creando la clase poniendo como nombre clave la palabra var
        ProgramadoresArrays var = new ProgramadoresArrays();
        // Creando mi arreglo de texto y uno de ayuda(temp);
        string[] texto = new string[0];
        string[] temp;

        // Esto hará iniciar los componentes del proyecto
        public Form1()
        {
            InitializeComponent();
        }

        // Método del formulario cuando este cargado
        private void Form1_Load(object sender, EventArgs e)
        {
            // Método para centrar el título del Form
            void UpdateTextPosition()
            {
                Graphics g = this.CreateGraphics();
                Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
                Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
                String tmp = " ";
                Double tmpWidth = 0;

                while ((tmpWidth + widthOfASpace) < startingPoint)
                {
                    tmp += " ";
                    tmpWidth += widthOfASpace;
                }

                this.Text = tmp + this.Text.Trim();
            }
            // Llamando al método de centrar texto
            UpdateTextPosition();
            // Poniendo la variable acc en 1 que nos ayudará en los arreglos
            var.Acc = 1;
        }

        // Método del evento keypress del textbox(ingresar texto)
        private void Caja_Registrar_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Evitar que escribe algun signo y solo texto  
            if (e.KeyChar >= 33 && e.KeyChar <= 64 || e.KeyChar >= 91 && e.KeyChar <= 96 || e.KeyChar >= 123 && e.KeyChar <= 163 || e.KeyChar >= 166 && e.KeyChar <= 223)
            {
                MessageBox.Show("Recomendamos escribir texto, no números ni signos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
                return;
            }
        }

        // Método del boton registrar(donde se guardará los textos ingresados)
        private void Btn_Registrar_Click(object sender, EventArgs e)
        {
            // Comprobamos si el textbox de juegos esta vacío
            if (String.IsNullOrEmpty(Caja_Registrar.Text) || Caja_Registrar.Text[0] == ' ')
            {
                // Le mostramos un mensaje diciendo que complete el campo
                MessageBox.Show("Porfavor completa el campo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                try
                {
                    // En caso todo este correcto
                    // El richtextbox lo vaciamos para mostrar los nuevos datos
                    Caja_Mostrar.Text = "";

                    //Llamamos al método para agregar elementos
                    AgrandarArreglo();
                    // Llamamos al método para mostrar los elementos
                    Mostrar();

                    // Vaciar la caja registrar para que ingrese nuevos datos
                    Caja_Registrar.Text = "";
                } catch
                {
                    // Por si las dudas agregamos una excepción evitando algún problema extra
                    MessageBox.Show("Parece que hubo un error, intentalo de nuevo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Método para guardar elementos en el arreglo
        private void AgrandarArreglo()
        {
            try
            {
                // El código lo que hara es cada vez que registre un elemento
                // se agrandara 1 más el arreglo
                if (1 == var.Acc)
                {
                    texto = new string[var.Acc];
                    temp = new string[var.Acc];
                    texto[var.Acc - 1] = Caja_Registrar.Text.ToLower();
                    temp[var.Acc - 1] = Caja_Registrar.Text.ToLower();
                    var.Acc++;
                }
                else
                {
                    temp = new string[var.Acc];

                    int k = 0;
                    while (k < temp.Length)
                    {
                        if (k == temp.Length - 1)
                        {
                            temp[k] = Caja_Registrar.Text.ToLower();
                            break;
                        }
                        temp[k] = texto[k];
                        k++;
                    }

                    texto = new string[var.Acc];

                    int j = 0;
                    while (j < temp.Length)
                    {
                        texto[j] = temp[j];
                        j++;
                    }
                    var.Acc++;
                }
            } catch
            {
                // Por si las dudas agregamos una excepción evitando algún problema extra
                MessageBox.Show("Parece que hubo un error, intentalo de nuevo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método del botón ordenar
        private void Btn_Ordenar_Click(object sender, EventArgs e)
        {
            // Comprobamos que el usuario haya registrado elementos
            if (texto.Length == 0)
            {
                MessageBox.Show("Registrar elementos para ordenar!","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            } else
            {
                try
                {
                    // El richtextbox lo vaciamos para mostrar los nuevos datos
                    Caja_Mostrar.Text = "";

                    // En caso lo haya ordenado, mostrará un mensaje informando al usuario
                    MessageBox.Show(OrdenRecursivo(0, texto.Length), "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    // Llamamamos al método para mostrar los elementos
                    Mostrar();
                } catch
                {
                    // Por si las dudas agregamos una excepción evitando algún problema extra
                    MessageBox.Show("Parece que hubo un error, intentalo de nuevo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Este es la primera parte del algoritmo del método burbuja
        private string OrdenRecursivo(int i, int lim)
        {
            if (i < lim)
            {
                Recorrer(0,lim,i);
                return OrdenRecursivo(i + 1, lim);
            }
            return "Se ordeno el arreglo correctamente!";
        }
        // Esta es la segunda parte del método burbuja recursivo
        private void Recorrer(int j,int lim2,int res)
        {
            if (j < lim2 - res - 1)
            {
                if (texto[j + 1].First() < texto[j].First())
                {
                    var.Aux = texto[j];
                    texto[j] = texto[j + 1];
                    texto[j + 1] = var.Aux;
                }
                Recorrer(j + 1,lim2,res);
            }
        }

        // Método para mostrar los elementos en el richtextbox
        private void Mostrar()
        {
            try
            {
                // Recorre cada elemento del arreglo para mostrarlo
                foreach (string elem in texto)
                {
                    Caja_Mostrar.Text += elem + "\n";
                }
            } catch
            {
                // Por si las dudas agregamos una excepción evitando algún problema extra
                MessageBox.Show("Parece que hubo un error, intentalo de nuevo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    // Creando una clase que tendrá variables que nos ayudarán a lo largo del programa
    class ProgramadoresArrays
    {
        public int Acc { get; set; }
        public string Aux { get; set; }
        public string Content { get; set; }
    }
}
