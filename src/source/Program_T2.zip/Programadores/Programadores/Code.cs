﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Espacio de nombre Programadores
namespace Programadores
{
    // Creando una estructura de Medicamentos
    public struct Medicamentos
    {
        // Creo variables publicas accesibles y modificables de los medicamentos como nombre,codigo,cantidad,etc
        public string m_name, m_code, m_cant, m_pre, m_monto, m_mostrarMedi, m_search, m_del;
        public double m_montoEx;
        public string m_auxName, m_auxCode, m_auxCant, m_auxPre, m_auxMonto;
        public int m_acc;
    }
}
