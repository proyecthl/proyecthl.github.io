﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Espacio de nombre Programadores
namespace Programadores
{
    public partial class Form1 : Form
    {
        // creando medicamento apartir de la estructura "Medicamentos"
        Medicamentos medi = new Medicamentos();

        // Creo listas de cada elemento del medicamento
        public List<string> nombreList = new List<string>();
        public List<string> codigoList = new List<string>();
        public List<string> cantidadList = new List<string>();
        public List<string> precioList = new List<string>();
        public List<string> montoList = new List<string>();

        // incializar el form
        public Form1()
        {
            InitializeComponent();
        }

        // metodo que detecta pulsacion de tecla(keypress) evitando poner texto donde debe haber numeros
        private void CajaCantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        // metodo que detecta pulsacion de tecla(keypress) evitando poner texto donde debe haber numeros
        // en este caso hago excepcion al punto, ya que podria ser decimal el precio
        private void CajaPrecio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 45 || e.KeyChar == 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Solo numeros!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        // metodo del boton registrar
        private void Btn_Registrar_Click(object sender, EventArgs e)
        {
            // Al dar click se guardan el contenido de los textbox se guardan en las variables de la estructura Medicamentos de "Code.cs"
            medi.m_name = CajaNombre.Text;
            medi.m_code = CajaCodigo.Text;
            medi.m_cant = CajaCantidad.Text;
            medi.m_pre = CajaPrecio.Text;
            // Si los texbox estan vacios, mostrar ventana indicando que no puedes registrar vacios
            if (String.IsNullOrEmpty(medi.m_name) || String.IsNullOrEmpty(medi.m_code) || String.IsNullOrEmpty(medi.m_cant) || String.IsNullOrEmpty(medi.m_pre))
            {
                MessageBox.Show("No puedes registrar elementos vacios!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                // si los textbox estan llenos ejecutar codigo:
                // multiplicando cantidad x precio para el monto invertido
                medi.m_montoEx = double.Parse(medi.m_cant) * double.Parse(medi.m_pre);
                // conviertiendo numero a texto para imprimir el monto invertido
                medi.m_monto = medi.m_montoEx.ToString();
                // agregando elementos a su respectiva lista
                nombreList.Add(medi.m_name);
                codigoList.Add(medi.m_code);
                cantidadList.Add(medi.m_cant);
                precioList.Add(medi.m_pre);
                montoList.Add(medi.m_monto);
                // mostrando ventana emergente indicando que se registro correctamente!
                MessageBox.Show("Se registro el medicamento correctamente!","Información",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }

        // metodo del boton mostrar
        private void Btn_Mostrar_Click(object sender, EventArgs e)
        {
            // si la lista de medicamentos esta vacia, mostrar que no hay medicamentos registrados
            if (nombreList.Count == 0)
            {
                MessageBox.Show("No se registro ni un medicamento!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                // si la lista contiene elementos
                // Ejecuta un bucle que recorre la lista
                for (int i = 0; i < nombreList.Count; i++)
                {
                    medi.m_mostrarMedi += "Nombre: " + nombreList[i] + " Codigo: " + codigoList[i] + " Precio: " + precioList[i] + " Cantidad: " + cantidadList[i] + " Monto Invertido: " + montoList[i] + "\n\n";
                }
                // mostrando las listas
                MessageBox.Show(medi.m_mostrarMedi, "Medicamentos", MessageBoxButtons.OK, MessageBoxIcon.None);
                // pongo la caja en vacio para que no se acumule y salga repetido
                medi.m_mostrarMedi = "";
            }
        }

        // metodo para el boton ordenar
        private void Btn_Ordenar_Click(object sender, EventArgs e)
        {
            // si la lista de medicamentos esta vacia, mostrar que no hay medicamentos registrados
            if (nombreList.Count == 0)
            {
                MessageBox.Show("No se registro ni un medicamento!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            } else
            {
                // si la lista tiene elementos ejecutar un metodo de ordenar con burbuja
                OrdenarBurbuja();
                // mostrando ventana indicando que se ordenaron correctamente
                MessageBox.Show("Medicamentos Ordenados!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // metodo burbuja llamado en el metodo del boton ordenar
        public void OrdenarBurbuja()
        {
            // algoritmo que compara las letras de los nombres para ordenar alfabeticamente
            for (int i = 0; i < nombreList.Count; i++)
            {
                for (int j = 0; j < nombreList.Count - i - 1; j++)
                {
                    // compara la primera letra de cada nombre para ordenarlo
                    if (nombreList[j].FirstOrDefault() > nombreList[j + 1].FirstOrDefault())
                    {
                        medi.m_auxName = nombreList[j];
                        nombreList[j] = nombreList[j + 1];
                        nombreList[j + 1] = medi.m_auxName;

                        medi.m_auxCode = codigoList[j];
                        codigoList[j] = codigoList[j + 1];
                        codigoList[j + 1] = medi.m_auxCode;

                        medi.m_auxCant = cantidadList[j];
                        cantidadList[j] = cantidadList[j + 1];
                        cantidadList[j + 1] = medi.m_auxCant;

                        medi.m_auxPre = precioList[j];
                        precioList[j] = precioList[j + 1];
                        precioList[j + 1] = medi.m_auxPre;

                        medi.m_auxMonto = montoList[j];
                        montoList[j] = montoList[j + 1];
                        montoList[j + 1] = medi.m_auxMonto;
                    }
                }
            }
        }

        // metodo del boton buscar
        private void Btn_Buscar_Click(object sender, EventArgs e)
        {
            // uso un acumulador incializandolo con 0
            medi.m_acc = 0;
            // guardo el contenido del texbox en una variable de la estructura de Medicamentos("Code.cs")
            medi.m_search = CajaMediNombre.Text;
            // bucle que recorre la lista de nombres
            for(int i = 0; i < nombreList.Count; i++)
            {
                // si la lista de nombre contiene el nombre que el usuario indico 
                if (nombreList[i].Contains(medi.m_search))
                {
                    // compruebo estrictamente para evitar errores
                    // si el elemento es igual al nombre indicado
                    if (nombreList[i] == medi.m_search)
                    {
                        // mostrar ventana indicando que se contro, mostrando tambien el medicamento
                        MessageBox.Show("Medicamento Encontrado!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        MessageBox.Show("Nombre: " + nombreList[i] + " Codigo: " + codigoList[i] + " Precio: " + precioList[i] + " Cantidad: " + cantidadList[i] + " Monto Invertido: " + montoList[i], "Medicamento", MessageBoxButtons.OK, MessageBoxIcon.None);
                        // el acumulador le sumo 1
                        medi.m_acc++;
                    }
                }
            }

            // si el acumulador es 0 significa que pudo encontrarlo
            if (medi.m_acc == 0)
            {
                MessageBox.Show("No se encontró el medicamento!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // metodo para el boton eliminar
        private void Btn_Eliminar_Click(object sender, EventArgs e)
        {
            // uso el acumulador en 0
            medi.m_acc = 0;
            // guardo el contenido del texbox en una variable de la estructura de Medicamentos("Code.cs")
            medi.m_del = CajaMediCodigo.Text;
            // bucle que recorre la lista de codigos
            for(int i = 0; i < codigoList.Count; i++)
            {
                // si la lista de codigos contiene el codigo que el usuario indico 
                if (codigoList[i].Contains(medi.m_del))
                {
                    // compruebo estrictamente para evitar errores
                    // si el elemento es igual al codigo indicado
                    if (codigoList[i] == medi.m_del)
                    {
                        // elimino el medicamento de la lista de medicamentos y del codigo
                        nombreList.Remove(nombreList[i]);
                        codigoList.Remove(codigoList[i]);
                        cantidadList.Remove(cantidadList[i]);
                        precioList.Remove(precioList[i]);
                        montoList.Remove(montoList[i]);
                        // mostrar ventana emergente informando que fue eliminado correctamente
                        MessageBox.Show("Medicamento Eliminado!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // acumulador le sumo 1
                        medi.m_acc++;
                    }
                }
            }
            
            // si el acumulador es 0 significa que pudo encontrarlo
            if(medi.m_acc == 0)
            {
                MessageBox.Show("No se encontró el medicamento!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
            // Code created by Happy Life
            // Discord: https://discord.gg/9fhrdaekpT
            // Sitio Web: https://happylifeproyect.000webhostapp.com/index.html
    }
}
