﻿namespace Programadores
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.CajaNombre = new System.Windows.Forms.TextBox();
            this.CajaCodigo = new System.Windows.Forms.TextBox();
            this.CajaCantidad = new System.Windows.Forms.TextBox();
            this.CajaPrecio = new System.Windows.Forms.TextBox();
            this.Btn_Registrar = new System.Windows.Forms.Button();
            this.Btn_Mostrar = new System.Windows.Forms.Button();
            this.Btn_Ordenar = new System.Windows.Forms.Button();
            this.CajaMediCodigo = new System.Windows.Forms.TextBox();
            this.CajaMediNombre = new System.Windows.Forms.TextBox();
            this.Btn_Buscar = new System.Windows.Forms.Button();
            this.Btn_Eliminar = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(263, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(314, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Registro Farmacéutico";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(98, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(98, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Cantidad:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(443, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Código:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(419, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 19);
            this.label5.TabIndex = 4;
            this.label5.Text = "Precio Unitario:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(147, 254);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(214, 32);
            this.label6.TabIndex = 5;
            this.label6.Text = "Medicamentos:";
            // 
            // CajaNombre
            // 
            this.CajaNombre.Location = new System.Drawing.Point(214, 80);
            this.CajaNombre.Name = "CajaNombre";
            this.CajaNombre.Size = new System.Drawing.Size(147, 20);
            this.CajaNombre.TabIndex = 6;
            // 
            // CajaCodigo
            // 
            this.CajaCodigo.Location = new System.Drawing.Point(565, 80);
            this.CajaCodigo.Name = "CajaCodigo";
            this.CajaCodigo.Size = new System.Drawing.Size(147, 20);
            this.CajaCodigo.TabIndex = 7;
            // 
            // CajaCantidad
            // 
            this.CajaCantidad.Location = new System.Drawing.Point(214, 152);
            this.CajaCantidad.Name = "CajaCantidad";
            this.CajaCantidad.Size = new System.Drawing.Size(147, 20);
            this.CajaCantidad.TabIndex = 8;
            this.CajaCantidad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CajaCantidad_KeyPress);
            // 
            // CajaPrecio
            // 
            this.CajaPrecio.Location = new System.Drawing.Point(565, 152);
            this.CajaPrecio.Name = "CajaPrecio";
            this.CajaPrecio.Size = new System.Drawing.Size(147, 20);
            this.CajaPrecio.TabIndex = 9;
            this.CajaPrecio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CajaPrecio_KeyPress);
            // 
            // Btn_Registrar
            // 
            this.Btn_Registrar.Location = new System.Drawing.Point(331, 200);
            this.Btn_Registrar.Name = "Btn_Registrar";
            this.Btn_Registrar.Size = new System.Drawing.Size(183, 23);
            this.Btn_Registrar.TabIndex = 10;
            this.Btn_Registrar.Text = "Registrar";
            this.Btn_Registrar.UseVisualStyleBackColor = true;
            this.Btn_Registrar.Click += new System.EventHandler(this.Btn_Registrar_Click);
            // 
            // Btn_Mostrar
            // 
            this.Btn_Mostrar.Location = new System.Drawing.Point(400, 263);
            this.Btn_Mostrar.Name = "Btn_Mostrar";
            this.Btn_Mostrar.Size = new System.Drawing.Size(114, 23);
            this.Btn_Mostrar.TabIndex = 11;
            this.Btn_Mostrar.Text = "Mostrar";
            this.Btn_Mostrar.UseVisualStyleBackColor = true;
            this.Btn_Mostrar.Click += new System.EventHandler(this.Btn_Mostrar_Click);
            // 
            // Btn_Ordenar
            // 
            this.Btn_Ordenar.Location = new System.Drawing.Point(555, 263);
            this.Btn_Ordenar.Name = "Btn_Ordenar";
            this.Btn_Ordenar.Size = new System.Drawing.Size(114, 23);
            this.Btn_Ordenar.TabIndex = 12;
            this.Btn_Ordenar.Text = "Ordenar";
            this.Btn_Ordenar.UseVisualStyleBackColor = true;
            this.Btn_Ordenar.Click += new System.EventHandler(this.Btn_Ordenar_Click);
            // 
            // CajaMediCodigo
            // 
            this.CajaMediCodigo.Location = new System.Drawing.Point(349, 397);
            this.CajaMediCodigo.Name = "CajaMediCodigo";
            this.CajaMediCodigo.Size = new System.Drawing.Size(147, 20);
            this.CajaMediCodigo.TabIndex = 13;
            // 
            // CajaMediNombre
            // 
            this.CajaMediNombre.Location = new System.Drawing.Point(349, 324);
            this.CajaMediNombre.Name = "CajaMediNombre";
            this.CajaMediNombre.Size = new System.Drawing.Size(147, 20);
            this.CajaMediNombre.TabIndex = 14;
            // 
            // Btn_Buscar
            // 
            this.Btn_Buscar.Location = new System.Drawing.Point(555, 327);
            this.Btn_Buscar.Name = "Btn_Buscar";
            this.Btn_Buscar.Size = new System.Drawing.Size(75, 23);
            this.Btn_Buscar.TabIndex = 15;
            this.Btn_Buscar.Text = "Buscar";
            this.Btn_Buscar.UseVisualStyleBackColor = true;
            this.Btn_Buscar.Click += new System.EventHandler(this.Btn_Buscar_Click);
            // 
            // Btn_Eliminar
            // 
            this.Btn_Eliminar.Location = new System.Drawing.Point(555, 392);
            this.Btn_Eliminar.Name = "Btn_Eliminar";
            this.Btn_Eliminar.Size = new System.Drawing.Size(75, 23);
            this.Btn_Eliminar.TabIndex = 16;
            this.Btn_Eliminar.Text = "Eliminar";
            this.Btn_Eliminar.UseVisualStyleBackColor = true;
            this.Btn_Eliminar.Click += new System.EventHandler(this.Btn_Eliminar_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(232, 396);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 19);
            this.label7.TabIndex = 17;
            this.label7.Text = "Código:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(232, 325);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 19);
            this.label8.TabIndex = 18;
            this.label8.Text = "Nombre:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(41, 226);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(721, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = resources.GetString("label9.Text");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Btn_Eliminar);
            this.Controls.Add(this.Btn_Buscar);
            this.Controls.Add(this.CajaMediNombre);
            this.Controls.Add(this.CajaMediCodigo);
            this.Controls.Add(this.Btn_Ordenar);
            this.Controls.Add(this.Btn_Mostrar);
            this.Controls.Add(this.Btn_Registrar);
            this.Controls.Add(this.CajaPrecio);
            this.Controls.Add(this.CajaCantidad);
            this.Controls.Add(this.CajaCodigo);
            this.Controls.Add(this.CajaNombre);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Medicamentos Laboratorio";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox CajaNombre;
        private System.Windows.Forms.TextBox CajaCodigo;
        private System.Windows.Forms.TextBox CajaCantidad;
        private System.Windows.Forms.TextBox CajaPrecio;
        private System.Windows.Forms.Button Btn_Registrar;
        private System.Windows.Forms.Button Btn_Mostrar;
        private System.Windows.Forms.Button Btn_Ordenar;
        private System.Windows.Forms.TextBox CajaMediCodigo;
        private System.Windows.Forms.TextBox CajaMediNombre;
        private System.Windows.Forms.Button Btn_Buscar;
        private System.Windows.Forms.Button Btn_Eliminar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}

